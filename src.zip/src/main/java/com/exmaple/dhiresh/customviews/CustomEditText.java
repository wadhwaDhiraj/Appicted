package com.exmaple.dhiresh.customviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.EditText;

import com.exmaple.dhiresh.overflowmenu.R;

/**
 * Created by Sagar on 16-08-2016.
 */
public class CustomEditText extends EditText {
    public  Typeface typeface;
    public CustomEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(0);
    }

    public CustomEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray t = context.obtainStyledAttributes(attrs, R.styleable.CustomEditText);
        init(t.getInt(R.styleable.CustomEditText_fontTypeEt, 0));
    }


    public void init(int i) {
//        Typeface tf = Typeface.createFromAsset(getContext().getAssets(), "fonts/museo_sans_hundred.otf");
//        setTypeface(tf ,1);

        switch (i) {
            case 1:
                typeface = Typeface.createFromAsset(getContext().getAssets(), "fonts/roboto_regular.ttf");
                break;
            case 3:
                typeface = Typeface.createFromAsset(getContext().getAssets(), "fonts/roboto_italic.ttf");
                break;

            case 4:
                typeface = Typeface.createFromAsset(getContext().getAssets(), "fonts/roboto_bold.ttf");
                break;

            case 5:
                typeface = Typeface.createFromAsset(getContext().getAssets(), "fonts/roboto_medium.ttf");
                break;

            default:
                typeface = Typeface.createFromAsset(getContext().getAssets(), "fonts/roboto_light.ttf");
                break;
        }
        if (typeface != null)
            setTypeface(typeface, 1);

    }
}
