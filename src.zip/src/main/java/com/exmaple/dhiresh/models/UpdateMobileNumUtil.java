package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class UpdateMobileNumUtil {
    private Metadata meta_data;
    private UpdateMobileDetails update_status;

    public Metadata getMeta_data() {
        return meta_data;
    }

    public UpdateMobileDetails isUpdate_status() {
        return update_status;
    }
}
