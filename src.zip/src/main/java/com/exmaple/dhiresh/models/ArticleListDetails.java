package com.exmaple.dhiresh.models;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Sagar on 31-08-2016.
 */
public class ArticleListDetails implements Parcelable {

    String ID,ARTICLE_HEAD,ARTICLE_DESC,ARTICLE_IMG;

    protected ArticleListDetails(Parcel in) {
        ID = in.readString();
        ARTICLE_HEAD = in.readString();
        ARTICLE_DESC = in.readString();
        ARTICLE_IMG = in.readString();
    }

    public static final Creator<ArticleListDetails> CREATOR = new Creator<ArticleListDetails>() {
        @Override
        public ArticleListDetails createFromParcel(Parcel in) {
            return new ArticleListDetails(in);
        }

        @Override
        public ArticleListDetails[] newArray(int size) {
            return new ArticleListDetails[size];
        }
    };

    public String getID() {
        return ID;
    }

    public String getARTICLE_HEAD() {
        return ARTICLE_HEAD;
    }

    public String getARTICLE_DESC() {
        return ARTICLE_DESC;
    }

    public String getARTICLE_IMG() {
        return ARTICLE_IMG;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(ID);
        dest.writeString(ARTICLE_HEAD);
        dest.writeString(ARTICLE_DESC);
        dest.writeString(ARTICLE_IMG);
    }
}
