package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class AppAddDetails {

    String app_name;
    int app_time;
    boolean hideResult;

    public String getApp_name() {
        return app_name;
    }

    public int getApp_time() {
        return app_time;
    }

    public boolean hidePasswordMatch()
    {
        return hideResult;
    }
}



