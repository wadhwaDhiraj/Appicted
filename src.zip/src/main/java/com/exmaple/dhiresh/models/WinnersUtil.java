package com.exmaple.dhiresh.models;

import java.util.List;

/**
 * Created by Sagar on 23-09-2016.
 */

public class WinnersUtil {

    public Metadata meta_data;
    String winners_announced;
    List<Winners> winners;

    public Metadata getMeta_data() {
        return meta_data;
    }

    public String getWinners_announced() {
        return winners_announced;
    }

    public List<Winners> getWinners() {
        return winners;
    }
}
