package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class MobileCheckUtil {
    private Metadata meta_data;
    private MobileCheckDetails login_data;

    public Metadata getMeta_data() {
        return meta_data;
    }

    public MobileCheckDetails getLogin_data() {
        return login_data;
    }
}
