package com.exmaple.dhiresh.models;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Sagar on 30-08-2016.
 */
public class QuestionList implements Parcelable {

    String ID,QUES,OPT1,OPT2,OPT3,OPT4;

    protected QuestionList(Parcel in) {
        ID = in.readString();
        QUES = in.readString();
        OPT1 = in.readString();
        OPT2 = in.readString();
        OPT3 = in.readString();
        OPT4 = in.readString();
    }

    public static final Creator<QuestionList> CREATOR = new Creator<QuestionList>() {
        @Override
        public QuestionList createFromParcel(Parcel in) {
            return new QuestionList(in);
        }

        @Override
        public QuestionList[] newArray(int size) {
            return new QuestionList[size];
        }
    };

    public String getID() {
        return ID;
    }

    public String getQUES() {
        return QUES;
    }

    public String getOPT1() {
        return OPT1;
    }

    public String getOPT2() {
        return OPT2;
    }

    public String getOPT3() {
        return OPT3;
    }

    public String getOPT4() {
        return OPT4;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(ID);
        dest.writeString(QUES);
        dest.writeString(OPT1);
        dest.writeString(OPT2);
        dest.writeString(OPT3);
        dest.writeString(OPT4);
    }
}
