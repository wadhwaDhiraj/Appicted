package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class AppAddUtil {
    private Metadata meta_data;
    private AppAddDetails app_data;

    public Metadata getMeta_data() {
        return meta_data;
    }

    public AppAddDetails getApp_data() {
        return app_data;
    }
}
