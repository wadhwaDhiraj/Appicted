package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class VerifyOTPUtil {
    private Metadata meta_data;
    String otp_correct;

    public Metadata getMeta_data() {
        return meta_data;
    }

    public String getOtp_correct() {
        return otp_correct;
    }
}
