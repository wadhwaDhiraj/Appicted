package com.exmaple.dhiresh.models;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Sagar on 23-09-2016.
 */

public class Winners implements Parcelable{
    String name,image;

    protected Winners(Parcel in) {
        name = in.readString();
        image = in.readString();
    }

    public static final Creator<Winners> CREATOR = new Creator<Winners>() {
        @Override
        public Winners createFromParcel(Parcel in) {
            return new Winners(in);
        }

        @Override
        public Winners[] newArray(int size) {
            return new Winners[size];
        }
    };

    public String getName() {
        return name;
    }

    public String getImage() {
        return image;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(image);
    }
}
