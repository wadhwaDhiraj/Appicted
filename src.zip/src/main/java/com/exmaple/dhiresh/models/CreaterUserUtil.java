package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class CreaterUserUtil {

    private Metadata meta_data;
    private CreateUserDetails user_data;

    public Metadata getMeta_data() {
        return meta_data;
    }

    public CreateUserDetails getVendor_data() {
        return user_data;
    }
}
