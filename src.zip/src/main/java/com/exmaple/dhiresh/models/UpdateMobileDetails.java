package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class UpdateMobileDetails {

    String update_status;

    public String isUpdate_status() {
        return update_status;
    }
}



