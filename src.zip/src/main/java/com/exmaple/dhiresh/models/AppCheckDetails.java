package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class AppCheckDetails {

    String app,app_exists,app_time;

    public String getApp() {
        return app;
    }

    public String getApp_exists() {
        return app_exists;
    }

    public String getApp_time() {
        return app_time;
    }


}
