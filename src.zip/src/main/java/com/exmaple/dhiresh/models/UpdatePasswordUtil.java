package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 20-07-2016.
 */
public class UpdatePasswordUtil {
    private Metadata meta_data;
    String password_updated;

    public Metadata getMeta_data() {
        return meta_data;
    }

    public String getPassword_updated() {
        return password_updated;
    }
}
