package com.exmaple.dhiresh.models;

import android.content.pm.ActivityInfo;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by Reshma on 25-06-2016.
 */
public class AppsObj {

    private String appName;
    private Integer status;
    private Integer time;
    private Boolean flag;
    ActivityInfo activityInfo;
    private String apn;

    public AppsObj(){
    }

    public AppsObj(Boolean flag){

        this.flag=flag;
    }

    public AppsObj(String appName, Integer status, Boolean flag, ActivityInfo activityInfo, String apn) {
        this.appName = appName;
        this.status = status;
        this.flag = flag;
        this.activityInfo = activityInfo;
        this.apn = apn;
    }

    public Integer getTime() { return time;
        }

    public void setTime(Integer time) {
        this.time = time;
        Log.i("Time : ", time + "");
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public ActivityInfo getActivityInfo() {
        return activityInfo;
    }

    public void setActivityInfo(ActivityInfo activityInfo) {
        this.activityInfo = activityInfo;
    }

    public String getApn() {
        return apn;
    }

    public void setApn(String apn) {
        this.apn = apn;
    }
}
