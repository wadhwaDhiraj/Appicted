package com.exmaple.dhiresh.models;

import java.util.List;

/**
 * Created by Sagar on 31-08-2016.
 */
public class AppListUtil {

    private Metadata metadata;
    List<AppListDetails> AppList;

    public Metadata getMetadata() {
        return metadata;
    }

    public List<AppListDetails> getAppList() {
        return AppList;
    }
}
