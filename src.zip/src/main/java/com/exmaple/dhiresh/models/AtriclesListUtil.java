package com.exmaple.dhiresh.models;

import java.util.List;

/**
 * Created by Sagar on 31-08-2016.
 */
public class AtriclesListUtil {

    private Metadata metadata;
    List<ArticleListDetails> ArticleList;

    public Metadata getMetadata() {
        return metadata;
    }

    public List<ArticleListDetails> getArticleList() {
        return ArticleList;
    }
}
