package com.exmaple.dhiresh.models;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Sagar on 31-08-2016.
 */
public class AppListDetails implements Parcelable {

    String appName;
    String appActivityInfo;
    String packageManager;

    protected AppListDetails(Parcel in) {
        appName = in.readString();
        appActivityInfo=in.readString();
        packageManager=in.readString();
    }

    public static final Creator<AppListDetails> CREATOR = new Creator<AppListDetails>() {
        @Override
        public AppListDetails createFromParcel(Parcel in) {
            return new AppListDetails(in);
        }

        @Override
        public AppListDetails[] newArray(int size) {
            return new AppListDetails[size];
        }
    };

    public String getAppName() {
        return appName;
    }

    public String getAppActivityInfo() {
        return appActivityInfo;
    }

    public String getPackageManager() {
        return packageManager;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeString(appName);
        dest.writeString(appActivityInfo);
        dest.writeString(packageManager);
    }
}
