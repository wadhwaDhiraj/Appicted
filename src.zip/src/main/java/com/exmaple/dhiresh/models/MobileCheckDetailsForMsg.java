package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class MobileCheckDetailsForMsg {

    String mobile,mobile_exists;

    public String getMobile() {
        return mobile;
    }

    public String getMobile_exists() {
        return mobile_exists;
    }




}
