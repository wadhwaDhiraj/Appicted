package com.exmaple.dhiresh.models;

import java.util.List;

/**
 * Created by Sagar on 30-08-2016.
 */
public class QuestionListUtil {

    private Metadata metadata;
    private List<QuestionList> QuestionList;

    public Metadata getMetadata() {
        return metadata;
    }

    public List<QuestionList> getQuestionList() {
        return QuestionList;
    }
}
