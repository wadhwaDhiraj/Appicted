package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class MobileCheckDetails {

    String mobile,mobile_exists,otp,hidePassword;
            int noOfRows;

    public String getMobile() {
        return mobile;
    }

    public String getMobile_exists() {
        return mobile_exists;
    }

    public String getOtp() {
        return otp;
    }

    public int getNoOfRows() {
        return noOfRows;
    }

    public String getHidePassword() {
        return hidePassword;
    }
}



