package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class AddAppUtil {

    private Metadata meta_data;
    private AppCheckDetails app_data;

    public Metadata getMeta_data() {
        return meta_data;
    }

    public AppCheckDetails getApp_data() {
        return app_data;
    }
}
