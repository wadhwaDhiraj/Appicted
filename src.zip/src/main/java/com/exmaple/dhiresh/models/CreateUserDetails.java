package com.exmaple.dhiresh.models;

/**
 * Created by Sagar on 19-07-2016.
 */
public class CreateUserDetails {
    String user_created,user_id;

    public String getVendor_created() {
        return user_created;
    }

    public String getVendor_id() {
        return user_id;
    }
}


