/**
 * Copyright 2015 Google Inc. All Rights Reserved.
 * <p/>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p/>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p/>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.exmaple.dhiresh.gcm;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.exmaple.dhiresh.overflowmenu.LoginActivity;
import com.exmaple.dhiresh.overflowmenu.R;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.DashboardActivity;
import com.exmaple.dhiresh.utils.AppSettings;
import com.google.android.gms.gcm.GcmListenerService;

import java.net.MalformedURLException;



public class MyGcmListenerService extends GcmListenerService {

    private static final String TAG = "MyGcmListenerService";

    /**
     * Called when message is received.
     *
     * @param from SenderID of the sender.
     * @param data Data bundle containing message data as key/value pairs.
     *             For Set of keys use data.keySet().
     */
    // [START receive_message]
    @Override
    public void onMessageReceived(String from, Bundle data) {
        String title = data.getString("title");
        String message = data.getString("message");
        String subtitle=data.getString("subtitle");
        String tickerText=data.getString("tickerText");
        boolean vibrate=data.getBoolean("vibrate");
        boolean sound=data.getBoolean("sound");
        String largeIcon=data.getString("largeIcon");
        String smallIcon=data.getString("smallIcon");

        Log.d(TAG, "From: " + from);
        Log.d(TAG, "Message: " + message);

        if (from.startsWith("/topics/")) {
            // message received from some topic.
        } else {
            // normal downstream message.
        }

        // [START_EXCLUDE]
        /**
         * Production applications would usually process the message here.
         * Eg: - Syncing with server.
         *     - Store message in local database.
         *     - Update UI.
         */

        /**
         * In some cases it may be useful to show a notification indicating to the user
         * that a message was received.
         */

        String msg = message;

        saveMessage(message,title,subtitle,tickerText,sound,vibrate,largeIcon,smallIcon);
        //QNBNotofication qnbNotification = parseResponse(message);
        //saveMessage(qnbNotification);
        // [END_EXCLUDE]
    }

    private  void saveMessage(String msg,String title,String subtitle,String tickerText,boolean sound,boolean vibrate,String largeIcon,String smallIcon){
        // AppSettings.putData(this,AppSettings.NOTIFICATIONS,msg);
        try {



            sendNotification(msg, title, subtitle, tickerText, sound, vibrate, largeIcon, smallIcon);

        }catch(Exception e){

        }

        Intent intent = new Intent("message");
        sendBroadcast(intent);

    }

    /*private void saveMessage(QNBNotofication qnbNotification) {

        Gson gson = new Gson();
        String json = AppSettings.getData(this, AppSettings.NOTIFICATIONS);
        Type type = new TypeToken<ArrayList<QNBNotofication>>() {
        }.getType();
        List<QNBNotofication> qnbNotificationList = null;

        try {
            qnbNotificationList = gson.fromJson(json, type);
        } catch (Exception e) {
            qnbNotificationList = new ArrayList<>();
        }

        if(qnbNotificationList==null)
            qnbNotificationList=new ArrayList<>();

        qnbNotificationList.add(qnbNotification);

        json = gson.toJson(qnbNotificationList);
        LogUtils.Verbose("TAG", " Notification JSON " + json);
        AppSettings.putData(this, AppSettings.NOTIFICATIONS, json);
        sendNotification(qnbNotification.getMessage());

        Intent intent = new Intent("message");
        intent.putExtra("type", 2);
        sendBroadcast(intent);
    }


    private QNBNotofication parseResponse(String xml) {
        QNBNotofication qnbNotification = new QNBNotofication();

        try {

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new StringReader(xml));
            int eventType = xpp.getEventType();
            String text = "";

            while (eventType != XmlPullParser.END_DOCUMENT) {

                String tagname = xpp.getName();

                if (eventType == XmlPullParser.TEXT) {
                    text = xpp.getText();

                } else if (eventType == XmlPullParser.END_TAG) {
                    if (tagname.equalsIgnoreCase("Timestamp")) {

                        try {
                            SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
                            SimpleDateFormat sdf2 = new SimpleDateFormat("dd");
                            SimpleDateFormat sdf3 = new SimpleDateFormat("MMM");

                            Date d1 = sdf1.parse(text);
                            qnbNotification.setTimestamp(sdf2.format(d1) + "\n" + sdf3.format(d1));

                        } catch (Exception e) {
                            qnbNotification.setTimestamp("N.A.");
                        }
                    }
                    if (tagname.equalsIgnoreCase("Message"))
                        qnbNotification.setMessage(text);

                }
                eventType = xpp.next();
            }
        } catch (Exception e) {
            e.printStackTrace();

        }

        return qnbNotification;
    }
    */// [END receive_message]

    /**
     * Create and show a simple notification containing the received GCM message.
     *
     * @param message GCM message received.
     */
   /* private void sendNotification(String message) {

        LogUtils.Verbose("TAG", " Message Received " + message);
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 *//* Request code *//*, intent,
                PendingIntent.FLAG_ONE_SHOT);

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("QNB Message")
                .setContentText(message)
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(null);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(0 *//* ID of notification *//*, notificationBuilder.build());
    }*/

    private void sendNotification(String message,String title,String subtitle,String tickerText,boolean sound,boolean vibrate,String largeIcon,String smallIcon) throws MalformedURLException {
        Intent intent=null;
        if(Boolean.parseBoolean(AppSettings.getData(getApplicationContext(), AppSettings.IS_LOGIN))){
            intent = new Intent(this, DashboardActivity.class);
        }else{
            intent = new Intent(this, LoginActivity.class);
        }

        int requestID = (int) System.currentTimeMillis();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, requestID /* Request code */, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);

        Bitmap remote_picture = null;
        try{
            //remote_picture = BitmapFactory.decodeStream((InputStream) new URL(largeIcon);
        }catch (Exception e){

        }

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("")
                .setContentText(message)
                .setAutoCancel(true)
                .setTicker("")
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message))
                .setSound(defaultSoundUri)
                .setContentIntent(null);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(requestID /* ID of notification */, notificationBuilder.build());
    }

    /*private PendingIntent getNotificationPendingIntent() {
        // Creates an explicit intent for an Activity in your app
        Intent resultIntent = new Intent(this, UtilityBills.class);

        // The stack builder object will contain an artificial back stack for the
        // started Activity.
        // This ensures that navigating backward from the Activity leads out of
        // your application to the Home screen.
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);

        // Adds the back stack for the Intent (but not the Intent itself)
        stackBuilder.addParentStack(UtilityBills.class);

        // Adds the Intent that starts the Activity to the top of the stack
        stackBuilder.addNextIntent(resultIntent);

        return stackBuilder.getPendingIntent(0,PendingIntent.FLAG_UPDATE_CURRENT);

    }*/
}