package com.exmaple.dhiresh.utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Sagar on 19-07-2016.
 */
public class AppSettings {

    public static String VENDOR_CODE="VENDOR_CODE";
    public static String SUBS_TYPE="SUBS_TYPE";
    public static String IS_LOGIN = "IsLoggedIn";
    public static String NOTIFICATIONS = "NOTIFICATIONS";
    public static String MOBILE_NO = "MOBILE_NO";

    public static void putData(Context context, String key, String value) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("consumer",context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();
    }


    public static String getData(Context context,String key) {
        if(context==null)
            return null;
        SharedPreferences preferences = context.getSharedPreferences("consumer", context.MODE_PRIVATE);
        return preferences.getString(key, "");
    }
}
