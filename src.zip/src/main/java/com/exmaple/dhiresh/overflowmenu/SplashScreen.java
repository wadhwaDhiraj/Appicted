package com.exmaple.dhiresh.overflowmenu;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.exmaple.dhiresh.overflowmenu.R;
import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.dialogs.OkDialog;
import com.exmaple.dhiresh.dialogs.UpdateLaterDialouge;
import com.exmaple.dhiresh.models.AtriclesListUtil;
/*import com.exmaple.dhiresh.models.Winners;
import com.exmaple.dhiresh.models.WinnersUtil;*/
import com.exmaple.dhiresh.utils.Constants;

public class SplashScreen extends AppCompatActivity {

    String version,mobilenumber,versionName;
    int ok = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        PackageInfo pInfo = null;
        try {
            pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            versionName =pInfo.versionName;
            int j =pInfo.versionCode;
            Log.v("VERSIONNAME ",versionName);

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

     //   versioncheckapicall();

    }

  /*  private void versioncheckapicall() {

        RetrofitTask.getInstance(SplashScreen.this).version(new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                if (!isSuccess) {
                    new OkDialog(SplashScreen.this, getString(R.string.somethingwentwrong), null, null);
                    return;
                }

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject metadata = jsonObject.getJSONObject("metadata");

                    String versionApi = metadata.getString("version");

                    float versionNameLocal = Float.parseFloat(versionName);
                    Log.v("LOCAl", versionNameLocal + "");
                    float versionNameApi1 = Float.parseFloat(versionApi);
                    Log.v("API", versionNameApi1 + "");

                    if (versionNameLocal != versionNameApi1) {
                        ok = 1;
                        String message = "New Version of Bot-O-Bot has been made avaliable for you.";
                        new UpdateLaterDialouge(SplashScreen.this, message, "UPDATE", "Alert", new UpdateLaterDialouge.IYesNoDialogCallback() {
                            @Override
                            public void handleResponse(int responsecode) {
                                if (responsecode == 1) {
                                    Intent intent = new Intent(Intent.ACTION_VIEW);
                                    intent.setData(Uri.parse("market://details?id=smartify.bot_o_bot"));
                                    try {
                                        startActivity(intent);
                                        System.exit(1);
                                    } catch (Exception e) {
                                        intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=smartify.bot_o_bot"));
                                    }
                                } else {
                                    ok = 1;
                                    *//*Intent intent = new Intent(SplashScreen.this,DashboardActivity.class);
                                    startActivity(intent);
                                    finish();*//*
                                    Toast.makeText(SplashScreen.this, "Winners Api Call", Toast.LENGTH_SHORT).show();
                                    // winnersApiCall();
                                }
                            }
                        });
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (ok == 0) {
                    *//*Intent intent = new Intent(SplashScreen.this, DashboardActivity.class);
                    startActivity(intent);
                    finish();*//*
                    Toast.makeText(SplashScreen.this, "Winners Api Call", Toast.LENGTH_SHORT).show();
                    // winnersApiCall();
                }
            }
        });
    }
*/
   /* public void winnersApiCall(){
        Map<String,String> paramMap = new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("week","1");
        RetrofitTask.getInstance(SplashScreen.this).winners(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                if(!isSuccess){
                    new OkDialog(SplashScreen.this, getString(R.string.somethingwentwrong), null, null);
                    return;
                }

                Gson gson= new Gson();
                Type type = new TypeToken<WinnersUtil>() {}.getType();
                WinnersUtil winnersUtil=null;
                winnersUtil = gson.fromJson(response,type);

                if(winnersUtil.getMeta_data().getCall_status().equals("1")){
                    Intent intent = new Intent(getApplicationContext(),WinnersActivity.class);
                    intent.putParcelableArrayListExtra("winnersList", (ArrayList<Winners>) winnersUtil.getWinners());
                    startActivity(intent);
                    finish();
                }

            }
        });

    }*/
}
