package com.exmaple.dhiresh.overflowmenu.smartify;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;



import com.exmaple.dhiresh.overflowmenu.R;

public class SuccessActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);
    }
}
