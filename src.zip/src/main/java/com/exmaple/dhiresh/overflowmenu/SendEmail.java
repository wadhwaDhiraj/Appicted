package com.exmaple.dhiresh.overflowmenu;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SendEmail extends AppCompatActivity {

    Button button;
    GMailSender sender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_email);
        button = (Button)findViewById(R.id.EmailButton);
        sender = new GMailSender("replytosushi@gmail.com", "shrini91");

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.
                Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                try {
                    new MyAsyncClass().execute();
                }
                catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_LONG).show();
                }

            }
        });
    }

        class MyAsyncClass extends AsyncTask<Void, Void, Void> {

            ProgressDialog pDialog;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                pDialog = new ProgressDialog(SendEmail.this);
                pDialog.setMessage("Please wait...");
                pDialog.show();

            }

            @Override
            protected Void doInBackground(Void... mApi) {
                try {
                    // Add subject, Body, your mail Id, and receiver mail Id.
                 //   appList.checkAppStart();
                    SharedPreferences sharedpreferences;
                    sharedpreferences = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
                  String myEmailId=sharedpreferences.getString("myEmailId",null);
                    sender.sendMail("Dhiresh app", " body", myEmailId, "replytosushi@gmail.com");
                 //   startService(new Intent(getBaseContext(), MyAccessibilityService.class));
                }
                catch (Exception ex) {
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void result) {
                super.onPostExecute(result);
                pDialog.cancel();
                Toast.makeText(getApplicationContext(), "Email sent", Toast.LENGTH_LONG).show();
            }


        }


}
