package com.exmaple.dhiresh.overflowmenu;

import android.annotation.TargetApi;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.SortedMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;

/**
 * Created by Reshma on 09-07-2016.
 */
public class MyAccessibilityService extends Service
{

   AppList appList;
    MyDBHandler dbHandler;
    List<String> checkedApps;

    public IBinder onBind(Intent arg0) {
        // TODO Auto-generated method stub
        return null;
    }



   /* @Override
        public void onAccessibilityEvent(AccessibilityEvent event) {
         Toast.makeText(this,"Service Actually Connected",Toast.LENGTH_SHORT).show();
    }

    @TargetApi(21)
    @Override
    public void onServiceConnected(){
         AccessibilityServiceInfo info = new AccessibilityServiceInfo();
         info.eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED | AccessibilityWindowInfo.TYPE_SYSTEM
                 | AccessibilityWindowInfo.TYPE_APPLICATION | AccessibilityEvent.TYPE_WINDOWS_CHANGED;
        setServiceInfo(info);
        Toast.makeText(this,"Service Connected",Toast.LENGTH_SHORT).show();
    }

    @Override
        public void onInterrupt() {
                  Toast.makeText(this,"Service DisConnected",Toast.LENGTH_SHORT).show();
    }

  //  @Override
    public void onInitializeAccessibilityEvent(AccessibilityEvent event) {
    //    super.onInitializeAccessibilityEvent(event);
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            // Action mode started
            //TODO event.setSource(this);
            event.setClassName(getClass().getName());
            event.setPackageName(this.getPackageName());
          //  event.setContentDescription(mTitle);
        } else {
            //TODO super.onInitializeAccessibilityEvent(event);
        }
    }

    private boolean isRunningService(String processname){
        if(processname==null || processname.isEmpty())
            return false;

        ActivityManager.RunningServiceInfo service;
        ActivityManager mActivityManager = (ActivityManager)this.getSystemService(Context.ACTIVITY_SERVICE);
        
        if(mActivityManager==null)
            mActivityManager = (ActivityManager)this.getSystemService(Context.ACTIVITY_SERVICE);
        List <ActivityManager.RunningServiceInfo> l = mActivityManager.getRunningServices(9999);
        Iterator <ActivityManager.RunningServiceInfo> i = l.iterator();
        while(i.hasNext()){
            service = i.next();
            if(service.process.equals(processname))
                return true;
        }

        return false;
    }

    */

    @TargetApi(21)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        super.onStartCommand(intent, flags, startId);

        Toast.makeText(this,"Process started",Toast.LENGTH_SHORT).show();

        dbHandler = new MyDBHandler(this, null, null, 1);
        checkedApps = dbHandler.getAllAppsPm();

       /* ActivityManager.RunningAppProcessInfo result=null, info=null;

        ProcessManager processManager = new ProcessManager();
        List<ProcessManager.Process> procInfos = processManager.getRunningApps();

        ActivityManager mActivityManager = (ActivityManager)this.getSystemService(Context.ACTIVITY_SERVICE);
        List <ActivityManager.RunningAppProcessInfo> l = mActivityManager.getRunningAppProcesses();
        Iterator<ActivityManager.RunningAppProcessInfo> i = l.iterator();
        while(i.hasNext()){
            info = i.next();
            if(info.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND){
                result=info;

                break;
            }
        }

        String r ;
        if(result == null)
            r = "nothing";
        else
            r = result.processName.toString();

        Toast.makeText(this,r,Toast.LENGTH_SHORT).show(); */ // Showing the Top Activity


            //    Toast.makeText(this,"Working 22",Toast.LENGTH_SHORT).show();
            UsageStatsManager uSM = (UsageStatsManager)getSystemService(USAGE_STATS_SERVICE);
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.YEAR, -2);
            long start = cal.getTimeInMillis();
            long time = System.currentTimeMillis();

            String currentApp = "NULL";
            UsageStatsManager usm = (UsageStatsManager) this.getSystemService(Context.USAGE_STATS_SERVICE);
            List<UsageStats> appList = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, time - 1000*1000, time);

            if (appList != null && appList.size() > 0) {
                SortedMap<Long, UsageStats> mySortedMap = new TreeMap<Long, UsageStats>();

                for (UsageStats usageStats : appList) {
                    mySortedMap.put(usageStats.getLastTimeUsed(), usageStats);
                }

                if (mySortedMap != null && !mySortedMap.isEmpty()) {
                    currentApp = mySortedMap.get(mySortedMap.lastKey()).getPackageName();
                }
            }
            Toast.makeText(this,"Current App : "+currentApp,Toast.LENGTH_SHORT).show();

            List<UsageStats> queryUsageStats = uSM.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, time - 1000*1000, time);
            UsageStats stats2 = null;

            String info=null;
            // Intent intent = new Intent(Settings.);
            //  startActivity(intent);

            //  Iterator<ProcessManager.Process> i = procInfos.iterator();

            MyDBHandler dbHandler;
            List<String> checkedApps;
            dbHandler = new MyDBHandler(this, null, null, 1);
            checkedApps = dbHandler.getAllAppsPm();

            Iterator<String> i = checkedApps.iterator();

            for(UsageStats stats:  queryUsageStats){
                Log.e("TAG", "Usage stats forrr: " + stats.getPackageName());
                stats2 = stats;
                while(i.hasNext()){
                    info = i.next();
                    if(stats.getPackageName().contains(info)){
                        Toast.makeText(this,"Yes it does : "+info,Toast.LENGTH_SHORT).show();
                        break;
                    }
                }
                i = checkedApps.iterator();

            }




        /*for (int index = 0; index < procInfos.size(); index++) {
            for (int j = 0; j < checkedApps.size(); j++)
            {
                if (procInfos.get(index).name.substring(procInfos.get(index).name.lastIndexOf('.') + 1, procInfos.get(index).name.length()).equalsIgnoreCase(checkedApps.get(j).substring(checkedApps.get(j).lastIndexOf('.') + 1, checkedApps.get(j).length())))
                {
                    Toast.makeText(this, procInfos.get(index).name.substring(procInfos.get(index).name.lastIndexOf('.') + 1, procInfos.get(index).name.length()), Toast.LENGTH_SHORT).show();
             //       Toast.makeText(this, checkedApps.get(j).substring(checkedApps.get(j).lastIndexOf('.')+1,checkedApps.get(j).length()), Toast.LENGTH_SHORT).show();
                    Toast.makeText(getApplicationContext(), "Browser is running", Toast.LENGTH_SHORT).show();
                } else {
                 //   Toast.makeText(this, procInfos.get(index).name.substring(procInfos.get(index).name.lastIndexOf('.')+1,procInfos.get(index).name.length()), Toast.LENGTH_SHORT).show();
                   *//* Toast.makeText(this, procInfos.get(i).name.substring(procInfos.get(i).name.lastIndexOf('.')+1,procInfos.get(i).name.length()), Toast.LENGTH_SHORT).show();
                    Toast.makeText(this, checkedApps.get(j).substring(checkedApps.get(j).lastIndexOf('.')+1,checkedApps.get(j).length()), Toast.LENGTH_SHORT).show();*//*
                    *//*Toast.makeText(getApplicationContext(), "Browser is not running", Toast.LENGTH_SHORT).show();*//*
                }

            }

        }*/

        return START_STICKY;
    }

    private static long UPDATE_INTERVAL = 1*5*1000;  //default
    private static Timer timer = new Timer();

    @Override
    public void onCreate(){
        super.onCreate();
        _startService();

    }

    private void _startService()
    {
        timer.scheduleAtFixedRate(

                new TimerTask() {

                    public void run() {

                        doServiceWork();

                    }
                }, 1000,UPDATE_INTERVAL);
        Log.i(getClass().getSimpleName(), "FileScannerService Timer started....");
    }

    private void doServiceWork()
    {
        //do something wotever you want
        //like reading file or getting data from network
        try {
            Toast.makeText(this,"Doing some work",Toast.LENGTH_SHORT).show();
        }
        catch (Exception e) {
        }

    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // TODO Auto-generated method stub
        Intent restartService = new Intent(getApplicationContext(),
                this.getClass());
        restartService.setPackage(getPackageName());
        PendingIntent restartServicePI = PendingIntent.getService(
                getApplicationContext(), 1, restartService,
                PendingIntent.FLAG_ONE_SHOT);

        //Restart the service once it has been killed android


        AlarmManager alarmService = (AlarmManager)getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        alarmService.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() +100, restartServicePI);

    }

    @Override
    public void onDestroy() {
        Toast.makeText(this,"Process stopped",Toast.LENGTH_SHORT).show();
        super.onDestroy();
    }


}

