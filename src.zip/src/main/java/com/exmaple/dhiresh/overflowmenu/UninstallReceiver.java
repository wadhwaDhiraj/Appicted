package com.exmaple.dhiresh.overflowmenu;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class UninstallReceiver extends BroadcastReceiver {

        public UninstallReceiver() {

        }

        @Override
        public void onReceive(Context context, Intent intent) {
            // TODO: This method is called when the BroadcastReceiver is receiving
            // an Intent broadcast.
            Log.d("Receiver", "Intent: " + intent.getAction());
            intent.getAction();
            Toast.makeText(context, "Game over baby", Toast.LENGTH_SHORT).show();
            MainActivity m = new MainActivity();
     //       m.startService(new Intent(context, MyAccessibilityService.class));
          }
    }



