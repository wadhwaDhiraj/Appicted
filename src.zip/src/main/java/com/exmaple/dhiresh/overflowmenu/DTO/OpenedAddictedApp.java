package com.exmaple.dhiresh.overflowmenu.DTO;

/**
 * Created by shrini on 28/8/16.
 */
public class OpenedAddictedApp {

    public String appName,appPackage;
    public long date;

    public OpenedAddictedApp(String appName, String appPackage, long date) {
        this.appName = appName;
        this.appPackage = appPackage;
        this.date = date;
    }
    public OpenedAddictedApp(){}
    @Override
    public String toString() {
        return "OpenedAddictedApp{" +
                "appName='" + appName + '\'' +
                ", appPackage='" + appPackage + '\'' +
                ", date=" + date +
                '}';
    }
}
