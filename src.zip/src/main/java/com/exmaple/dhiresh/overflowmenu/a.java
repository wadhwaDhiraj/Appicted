package com.exmaple.dhiresh.overflowmenu;

import android.app.ActivityManager.RunningServiceInfo;

import java.util.Comparator;

/**
 * Created by Reshma on 09-07-2016.
 */
public class a implements Comparator {
    public a()
    {

    }

    public int a(RunningServiceInfo runningServiceInfo, RunningServiceInfo runningServiceInfo2)
    {
        return runningServiceInfo.service.getClassName().compareTo(runningServiceInfo2.service.getClassName());
    }
    @Override
    public int compare(Object lhs, Object rhs) {
        return a((RunningServiceInfo)lhs,(RunningServiceInfo)rhs);
    }
}
