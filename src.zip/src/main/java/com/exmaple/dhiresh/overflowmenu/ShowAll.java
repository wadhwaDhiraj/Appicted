package com.exmaple.dhiresh.overflowmenu;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.List;

public class ShowAll extends AppCompatActivity {

    MyDBHandler dbHandler;
    AppList appList=new AppList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


    }

    public void onClick(View v){
        dbHandler = new MyDBHandler(getApplicationContext(), null, null, 1);

        List<String> apps= dbHandler.getAllApps();
        ListAdapter buckysAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, apps);
        setContentView(R.layout.db);
        ListView app=(ListView)findViewById(R.id.listView);
        app.setAdapter(buckysAdapter);


    }




}
