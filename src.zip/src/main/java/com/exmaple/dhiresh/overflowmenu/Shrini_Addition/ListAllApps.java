package com.exmaple.dhiresh.overflowmenu.Shrini_Addition;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.Toast;

import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.dialogs.OkDialog;
import com.exmaple.dhiresh.models.AppAddUtil;
import com.exmaple.dhiresh.models.AppListDetails;
import com.exmaple.dhiresh.models.AppListUtil;
import com.exmaple.dhiresh.models.MobileCheckUtil;
import com.exmaple.dhiresh.models.AppsObj;
import com.exmaple.dhiresh.models.UpdateTimeUtil;
import com.exmaple.dhiresh.overflowmenu.AppList;
import com.exmaple.dhiresh.overflowmenu.CustomAdapter;
import com.exmaple.dhiresh.overflowmenu.MyDBHandler;
import com.exmaple.dhiresh.overflowmenu.R;
import com.exmaple.dhiresh.utils.AppSettings;
import com.exmaple.dhiresh.utils.Constants;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListAllApps extends AppCompatActivity implements SearchView.OnQueryTextListener {
    MyDBHandler dbHandler;
    public static List<String> checkedApps=new ArrayList<>();
    public static List<String> checkedAppsPm=new ArrayList<>();
    public static List<String> checkedAppsActivityInfo=new ArrayList<>();
    List<ResolveInfo> sortedApps = null;
    CustomAdapter appsAdapter = null;
    ListView appsListView = null;
    List<ResolveInfo> apps;
    List<ResolveInfo> searchApp=new ArrayList<>();
    SearchView searchView;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;
    PackageManager packageManager;

    AdView mAdView;

    public void loadBannerAds(){

        mAdView = (AdView)findViewById(R.id.ad_view);
        if(mAdView!=null) {
            AdRequest adRequest = new AdRequest.Builder()
                    .setGender(AdRequest.GENDER_FEMALE)
                    .build();
            mAdView.loadAd(adRequest);
            Log.e("Ad ", "Added");
        }
        else
            Toast.makeText(this, "mAdView is Null", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_all_apps);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("All Apps");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        try {
            apps = getInstalledComponentList();
            }
        catch (PackageManager.NameNotFoundException e) {
            Toast.makeText(findViewById(R.id.view).getContext(), "Apps Not Found", Toast.LENGTH_LONG).show();
            return;
        }
        catch (Exception e)
        {
            Toast.makeText(findViewById(R.id.view).getContext(), "Error : "+e.getMessage(), Toast.LENGTH_LONG).show();
            return;
        }

        /*ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Loading");
        progressDialog.setMessage("Wait while loading...");
        progressDialog.setCancelable(false); // disable dismiss by tapping outside of the dialog
        progressDialog.show();*/
        // To dismiss the dialog

        checkedApps=getAllApps();

        dbHandler = new MyDBHandler(getApplicationContext(), null, null, 1);
        packageManager = getPackageManager();
        appsAdapter = new CustomAdapter(this, apps, packageManager, dbHandler);

        appsListView = (ListView) findViewById(R.id.AppListView);
        appsListView.setAdapter(appsAdapter);
        checkedAppsPm=getAllAppsPm();

        Log.e("checkedAppsPm List",checkedAppsPm.size()+"");

        if (checkedApps.contains(apps)) {
            Collections.sort(checkedApps, new Comparator<String>() {
                @Override
                public int compare(String arg1, String arg0) {
                    return arg1.compareToIgnoreCase(arg0);
                }
            });
        } else {
            Collections.sort(apps, new Comparator<ResolveInfo>() {
                @Override
                public int compare(ResolveInfo arg1, ResolveInfo arg0) {
                    return (arg1.loadLabel(packageManager).toString()).compareToIgnoreCase(arg0.loadLabel(packageManager).toString());
                }
            });
        }

        loadBannerAds();

        appsListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(final AdapterView<?> parent, final View view, final int position, long id) {
                        if (Constants.isNetworkAvailable(getApplicationContext()))
                        {
                            appsListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);

                        AlertDialog.Builder builder = new AlertDialog.Builder(ListAllApps.this);
                        LayoutInflater layoutInflater = LayoutInflater.from(ListAllApps.super.getApplicationContext());
                        View timeView = layoutInflater.inflate(R.layout.set_app_time, null);
                        builder.setView(timeView);
                        builder.setTitle("Set time (In Mins):");

                        final ResolveInfo ri = (ResolveInfo) parent.getItemAtPosition(position);
                        final ActivityInfo ac = ri.activityInfo;
                        final String apn = ri.activityInfo.applicationInfo.processName;
                        final String appName = (String) ri.loadLabel(packageManager);
                        final NumberPicker numberPicker = (NumberPicker) timeView.findViewById(R.id.numberPicker);

                        numberPicker.setBackgroundColor(000000);
                        numberPicker.setMinValue(1);
                        numberPicker.setMaxValue(60);
                        numberPicker.setPadding(10, 10, 10, 10);

                        if (!checkedApps.contains(appName)) {

                            builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    appsListView.invalidateViews();
                                    Integer t = numberPicker.getValue();

                                    addApp(ac, apn, appName, 1, t, ac.packageName);
                                    checkedApps = getAllApps();

                                    /*appsListView.setAdapter(appsAdapter);*/
                                    Toast.makeText(ListAllApps.this, "Adding app..", Toast.LENGTH_SHORT).show();

                                    finish();
                                }
                            });

                            builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Toast.makeText(ListAllApps.this, "Cancelled", Toast.LENGTH_SHORT).show();
                                }
                            });

                        } else {
                            builder.setPositiveButton(R.string.update, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    Integer t = numberPicker.getValue();
                                    updateTime(t, appName);
                                    Toast.makeText(ListAllApps.this, "Time Updated", Toast.LENGTH_SHORT).show();
                                    finish();

                                }
                            });

                            builder.setNegativeButton(R.string.remove, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    removeApp(appName);
                                    checkedApps = getAllApps();
                                    Log.e("Calling ", "NotifyDataSetChanged");

                                    removeAppMsg(appName);

                                    Toast.makeText(ListAllApps.this, "App Removed", Toast.LENGTH_SHORT).show();
                                    finish();

                                }
                            });

                        }

                        Dialog dialog = builder.create();
                        dialog.show();

                        int index = appsListView.getFirstVisiblePosition();
                        View v = appsListView.getChildAt(0);
                        int top = (v == null) ? 0 : v.getTop();
                        appsListView.setAdapter(appsAdapter);
                        appsListView.setSelectionFromTop(index, top);

                        }
                        else {
                            String message= getString(R.string.checkInternet);
                            if (message != null) {
                                new OkDialog(ListAllApps.this, message, null, null);
                            }
                            else
                            {
                                new OkDialog(ListAllApps.this, getString(R.string.somethingwentwrong), null, null);
                            }
                        }
                    }

                }

        );

        //progressDialog.dismiss();

        appsListView.setOnItemLongClickListener(
                new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                        int index = appsListView.getFirstVisiblePosition();
                        View v = appsListView.getChildAt(0);
                        int top = (v == null) ? 0 : v.getTop();
                        appsListView.setAdapter(appsAdapter);
                        appsListView.setSelectionFromTop(index, top);

                        return false;
                    }
                }
        );


        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }



    /*public void showProgress(String strMessage) {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(strMessage);
        progressDialog.show();
    }

    public void dismissProgress()
    {
        if(progressDialog!=null)
            progressDialog.dismiss();
    }*/

    private List<ResolveInfo> getInstalledComponentList()
            throws PackageManager.NameNotFoundException {

        final Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> ril = getPackageManager().queryIntentActivities(mainIntent, 0);
        return ril;
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @Override
    public void onBackPressed() {
        final Intent iAppList = new Intent(ListAllApps.this, DashboardActivity.class);
        Runnable r=new Runnable() {
            @Override
            public void run() {
                startActivity(iAppList);
            }
        };

        Thread appListThread=new Thread(r);
        appListThread.start();
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);

        final MenuItem searchItem = menu.findItem(R.id.search);

        try {
            searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
            searchView.setOnQueryTextListener(this);

            ImageView closeButton = (ImageView)searchView.findViewById(R.id.search_close_btn);

            // Set on click listener
            closeButton.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    appsAdapter = new CustomAdapter(getApplicationContext(), apps, getPackageManager(), dbHandler);
                    appsListView.setAdapter(appsAdapter);

                    //Clear query
                    searchView.setQuery("", false);
                    //Collapse the action view
                    searchView.onActionViewCollapsed();
                    //Collapse the search widget
                    searchItem.collapseActionView();

                }
            });

        } catch (NullPointerException e) {
            Toast.makeText(this, "searchItem is NULL", Toast.LENGTH_SHORT).show();
        }

        return true;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {

        if (!apps.isEmpty())
        {
            searchApp.clear();
            for (ResolveInfo appToBeSearched : apps) {
                String label = appToBeSearched.loadLabel(getPackageManager()).toString();
                if (label.toLowerCase().startsWith(query.toLowerCase()))
                {
                    Log.e("App added ", label + " " + query);

                    searchApp.add(appToBeSearched);
                }
            }

            if(searchApp.isEmpty())
            {
                Toast.makeText(ListAllApps.this, "No matches found", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Log.e("Beware ", "List is Empty");
            Toast.makeText(this, "List is Empty.", Toast.LENGTH_SHORT).show();
        }

        appsAdapter = new CustomAdapter(this, searchApp, packageManager, dbHandler);

    try {
        appsListView.setAdapter(appsAdapter);
        if(searchApp==null) {
            Log.e("searchApp empty ", "List is null");
        }
        else{
            Log.e("In Else Size : ", searchApp.size()+"");
            for (ResolveInfo appN : searchApp) {

                String label = appN.loadLabel(getPackageManager()).toString();
                Log.e("AppName  : ", label);
            }
        }
    }
    catch(NullPointerException e)
    {
        Log.e("Adapter list null : ", e.getMessage());
    }
    return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {

        if (!apps.isEmpty())
        {
            searchApp.clear();
            for (ResolveInfo appToBeSearched : apps) {
                String label = appToBeSearched.loadLabel(getPackageManager()).toString();
                if (label.toLowerCase().startsWith(newText.toLowerCase()))
                {
                    searchApp.add(appToBeSearched);
                }
            }

            if(searchApp.isEmpty())
            {
                Toast.makeText(ListAllApps.this, "No matches found", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Log.e("Beware ", "List is Empty");
            Toast.makeText(this, "List is Empty.", Toast.LENGTH_SHORT).show();
        }

        appsAdapter = new CustomAdapter(this, searchApp, packageManager, dbHandler);

        try {
            appsListView.setAdapter(appsAdapter);
            if(searchApp==null) {
                Log.e("searchApp empty ", "List is null");
            }
            else{
                Log.e("In Else Size : ", searchApp.size()+"");
                for (ResolveInfo appN : searchApp) {
                    String label = appN.loadLabel(getPackageManager()).toString();
                    Log.e("AppName  : ", label);
                }
            }
        }
        catch(NullPointerException e)
        {
            Log.e("Adapter list null : ", e.getMessage());
        }

        return false;
    }

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */

    private void addApp(ActivityInfo ac,String apn,String appName,Integer appStatus,Integer t, String packageManager) {
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("appActivityInfo", ac.toString());
        paramMap.put("appApn", apn);
        paramMap.put("appName", appName);
        paramMap.put("appStatus",appStatus.toString() );
        paramMap.put("appTime", t.toString());
        paramMap.put("mobile", AppSettings.getData(getApplicationContext(),AppSettings.MOBILE_NO));
        paramMap.put("packageManager", packageManager);
        appsListView.invalidateViews();
        RetrofitTask.getInstance(ListAllApps.this).addApp(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                if (!isSuccess) {
                    new OkDialog(ListAllApps.this, getString(R.string.somethingwentwrong), null, null);
    //              Toast.makeText(getApplicationContext(), "dismissProgress" + response, Toast.LENGTH_SHORT).show();
                    Log.e("addApp !success : ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<AppAddUtil>() {
                }.getType();
                AppAddUtil appAddUtil;
                appAddUtil = gson.fromJson(response, type);
                if (appAddUtil.getMeta_data().getCall_status().equals("1") && (!appAddUtil.getApp_data().getApp_name().equals(null))) {
                    Toast.makeText(ListAllApps.this, "addApp Successful", Toast.LENGTH_SHORT).show();
                    appsListView.invalidateViews();
                    new OkDialog(ListAllApps.this,"App Added","Success",null);



                } else {
                    String message = appAddUtil.getMeta_data().getMsg();
                    new OkDialog(ListAllApps.this, message+" addApp Else", null, null);
                }



            }
        });
    }


    private void removeApp(String appName) {
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("appName", appName);
        RetrofitTask.getInstance(ListAllApps.this).removeApp(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                if (!isSuccess) {
                    new OkDialog(ListAllApps.this, getString(R.string.checkInternet), null, null);

                    Log.e("removeApp !success : ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<AppAddUtil>() {
                }.getType();
                AppAddUtil appAddUtil;
                appAddUtil = gson.fromJson(response, type);
                Log.e("dismissProgress : ", response);
                if (appAddUtil.getMeta_data().getCall_status().equals("1")) {
                    appsListView.invalidateViews();
                    new OkDialog(ListAllApps.this,"App Removed","Success",null);
                } else {
                    String message = appAddUtil.getMeta_data().getMsg();
                    new OkDialog(ListAllApps.this, message+" Remove App failed", null, null);
                }
            }
        });
    }


    public List<String> getAllApps() {

        RetrofitTask.getInstance(ListAllApps.this).getAllApps(new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                if (!isSuccess) {

//                  Toast.makeText(getApplicationContext(), "dismissProgress" + response, Toast.LENGTH_SHORT).show();
                    Log.e("!isSuccess gAA : ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<AppListUtil>() {
                }.getType();
                AppListUtil appListUtil;
                appListUtil = gson.fromJson(response, type);
                if (appListUtil.getMetadata().getCall_status().equals("1") && !(appListUtil.getAppList().isEmpty())) {
                    checkedApps.clear();
                    for (int i = 0; i < appListUtil.getAppList().size(); i++) {
                        checkedApps.add(appListUtil.getAppList().get(i).getAppName());
                    }
                } else {
                    Toast.makeText(ListAllApps.this, "AppList is Empty", Toast.LENGTH_SHORT).show();
                    /*String message = appListUtil.getMetadata().getMsg();
                    new OkDialog(ListAllApps.this, message+" Error getAllApps", null, null);*/
                }
            }
        });
        return checkedApps;
    }

    public List<String> getAllAppsPm() {

        RetrofitTask.getInstance(ListAllApps.this).getAllApps(new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                if (!isSuccess) {
                    //Toast.makeText(getApplicationContext(), "dismissProgress" + response, Toast.LENGTH_SHORT).show();
                    Log.e("!isSucces gAAP : ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<AppListUtil>() {
                }.getType();
                AppListUtil appListUtil = null;
                appListUtil = gson.fromJson(response, type);
                Log.e("Response gAAP:", response);
                if (appListUtil.getMetadata().getCall_status().equals("1") && !(appListUtil.getAppList().isEmpty())) {
                    //Toast.makeText(ListAllApps.this, "in if gAAPm", Toast.LENGTH_SHORT).show();
                    checkedAppsPm.clear();
                    for (int i = 0; i < appListUtil.getAppList().size(); i++) {
                        checkedAppsPm.add(appListUtil.getAppList().get(i).getPackageManager());
                    }
                } else {
                    /*String message = appListUtil.getMetadata().getMsg();
                    new OkDialog(ListAllApps.this, message+" Error getAllAppsPm", null, null);*/
                    Toast.makeText(ListAllApps.this, "AppList is Empty", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return checkedAppsPm;
    }

    public List<String> getAllAppsActivityInfo() {

        RetrofitTask.getInstance(ListAllApps.this).getAllApps(new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                if (!isSuccess) {

      //              Toast.makeText(getApplicationContext(), "dismissProgress" + response, Toast.LENGTH_SHORT).show();
                    Log.e("dismissProg gAAAI : ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<AppListUtil>() {
                }.getType();
                AppListUtil appListUtil = null;
                appListUtil = gson.fromJson(response, type);
                Log.e("Response gAAAI:", response);
                if (appListUtil.getMetadata().getCall_status().equals("1") && !(appListUtil.getAppList().isEmpty())) {
                    Toast.makeText(ListAllApps.this, "getAllAppsActivityInfo is working", Toast.LENGTH_SHORT).show();
                    checkedAppsActivityInfo.clear();
                    for (int i = 0; i < appListUtil.getAppList().size(); i++) {
                        checkedAppsActivityInfo.add(appListUtil.getAppList().get(i).getAppActivityInfo());
                    }
                } else {
                    /*String message = appListUtil.getMetadata().getMsg();
                    new OkDialog(ListAllApps.this, message+" Error no apps getAllAppsActivityInfo", null, null);*/
                    Toast.makeText(ListAllApps.this, "AppList is Empty", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return checkedAppsActivityInfo;
    }

    void removeAppMsg(String appName)
    {
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("mobile", AppSettings.getData(getApplicationContext(),AppSettings.MOBILE_NO));
        paramMap.put("appName", appName);

        RetrofitTask.getInstance(ListAllApps.this).removeAppMsg(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                // dismissProgress();
                if (!isSuccess) {
                    new OkDialog(ListAllApps.this, getString(R.string.somethingwentwrong), null, null);
                    Log.e("dismissProg removeApp: ",response);
                    return;
                }

                Gson gson= new Gson();
                Type type = new TypeToken<MobileCheckUtil>() {}.getType();
                MobileCheckUtil mobilecheck = null;
                mobilecheck = gson.fromJson(response,type);
                //Log.e("response removeApp: ",response);
                // etmobilenumber.setText("");
                if(mobilecheck.getMeta_data().getCall_status().equals("1")){
                    //Toast.makeText(getApplicationContext(),"removeAppMsg working",Toast.LENGTH_SHORT).show();
                }else{
                    //Toast.makeText(getApplicationContext(),"Error removeAppMsg",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void updateTime(Integer t,String appName) {
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("newTime", t.toString());
        paramMap.put("appName",appName);

        RetrofitTask.getInstance(ListAllApps.this).updateTime(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                if (!isSuccess) {
                    new OkDialog(ListAllApps.this, getString(R.string.somethingwentwrong), null, null);
      //            Toast.makeText(getApplicationContext(), "dismissProgress" + response, Toast.LENGTH_SHORT).show();
                    Log.e("dismissProg updateT : ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<UpdateTimeUtil>() {
                }.getType();
                UpdateTimeUtil updateTimeUtil = null;
                updateTimeUtil = gson.fromJson(response, type);
                Log.e("dismissProg updateT: ", response);
                if (updateTimeUtil.getMeta_data().getCall_status().equals("1")) {
                    Toast.makeText(ListAllApps.this, "updateTime is working", Toast.LENGTH_SHORT).show();
                } else {
                    String message = updateTimeUtil.getMeta_data().getMsg();
                    new OkDialog(ListAllApps.this, message+" Error updateTime no apps", null, null);
                }
            }
        });
    }



}