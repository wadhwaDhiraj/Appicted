package com.exmaple.dhiresh.overflowmenu.smartify;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.dialogs.OkDialog;
import com.exmaple.dhiresh.models.AddAppUtil;
import com.exmaple.dhiresh.models.MobileCheckUtil;
import com.exmaple.dhiresh.models.AppsObj;
import com.exmaple.dhiresh.overflowmenu.BaseActivity;
import com.exmaple.dhiresh.overflowmenu.R;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.DashboardActivity;
import com.exmaple.dhiresh.utils.AppSettings;
import com.exmaple.dhiresh.utils.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class AppAdditionActivity extends BaseActivity {

    EditText etmobilenumber;
    String strMobileNumber;
    Button btnContinue;
    TextView existingUser,pagename;
    String forgotnew="1";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*setContentView(R.layout.activity_sign_up);*/
    }


}
