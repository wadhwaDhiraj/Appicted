package com.exmaple.dhiresh.overflowmenu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.models.AppAddUtil;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.DashboardActivity;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.ListAllApps;
import com.exmaple.dhiresh.utils.AppSettings;
import com.exmaple.dhiresh.utils.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DashboardSettings extends AppCompatActivity {

    static List<String> settingsMenu = new ArrayList<>();


    ListView settingsMenuListView = null;
    ArrayAdapter<String> arrayAdapter;
    CustomAdapterForSettings settingsAdapter = null;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor preferencesEditor;
    private static final int PREFERENCE_MODE_PRIVATE = 0;
    private static final String preferenceFileName = "AppictedPreferenceFile";

    String key = "Notification";
    String ON = "On";
    String OFF = "Off";
    String notifications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_settings);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        //TextView buckysText = (TextView) findViewById(R.id.buckysText);

        settingsMenu = getSettingsMenu();
        settingsAdapter = new CustomAdapterForSettings(this, settingsMenu);
        settingsMenuListView = (ListView)findViewById(R.id.SettingsMenu);
        settingsMenuListView.setAdapter(settingsAdapter);

        settingsMenuListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(final AdapterView<?> parent, final View view, final int position, long id) {

                if(position==0)
                {
                    final Intent iAppList = new Intent(DashboardSettings.this, Settings.class);
                    Runnable r=new Runnable() {
                        @Override
                        public void run() {
                            startActivity(iAppList);
                            finish();
                        }
                    };

                    Thread appListThread=new Thread(r);
                    appListThread.start();
                }
                else
                    if(position==1)
                    {
                        Toast.makeText(DashboardSettings.this, "Show number of messages remaining.", Toast.LENGTH_SHORT).show();
                    }
                    else
                        if(position==2)
                        {


                            notifications = "On"; //sharedPreferences.getString(key,"Off");

                            //Toast.makeText(DashboardSettings.this, "Value : "+notifications, Toast.LENGTH_SHORT).show();

                            if(notifications==sharedPreferences.getString(key,"Off").toString())
                            {
                                preferencesEditor = sharedPreferences.edit();
                                preferencesEditor.putString(key,OFF);
                                preferencesEditor.apply();
                                Toast.makeText(DashboardSettings.this, "Notifications are turned Off", Toast.LENGTH_SHORT).show();
                            }
                            else
                            {
                                preferencesEditor = sharedPreferences.edit();
                                preferencesEditor.putString(key,ON);
                                preferencesEditor.apply();
                                Toast.makeText(DashboardSettings.this, "Notifications are turned On", Toast.LENGTH_SHORT).show();
                            }

                        }
                        else
                            if(position==3)
                            {

                            }
            }
        }
        );

    }

    public List<String> getSettingsMenu()
    {
        settingsMenu.clear();

        settingsMenu.add("Update Mentor");
        settingsMenu.add("Messages remaining : ");
        settingsMenu.add("Notifications");
        settingsMenu.add("Help");

        return settingsMenu;
    }

}
