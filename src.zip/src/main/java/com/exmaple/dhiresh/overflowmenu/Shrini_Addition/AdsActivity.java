package com.exmaple.dhiresh.overflowmenu.Shrini_Addition;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.exmaple.dhiresh.overflowmenu.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

public class AdsActivity extends AppCompatActivity {

    InterstitialAd mInterstitialAd;
    AdView mAdView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ads);
        loadBannerAds();
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //loadAdsFullScreen();
    }

    public void loadBannerAds(){
        mAdView = (AdView)findViewById(R.id.ad_view);
        AdRequest adRequest = new AdRequest.Builder()
                .setGender(AdRequest.GENDER_FEMALE)
                .build();
        mAdView.loadAd(adRequest);
    }

    void loadAdsFullScreen(){
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getString(R.string.interstitial_ad));
        AdRequest request = new AdRequest.Builder()
                .setGender(AdRequest.GENDER_FEMALE)
                .tagForChildDirectedTreatment(true)
                .build();
        // Load ads into Interstitial Ads
        mInterstitialAd.loadAd(request);

        mInterstitialAd.setAdListener(new AdListener() {
            public void onAdLoaded() {
                showInterstitial1();
            }
        });
    }
    private void showInterstitial1() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();


        }
    }
}
