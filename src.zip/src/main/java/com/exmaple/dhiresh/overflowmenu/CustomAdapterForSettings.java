package com.exmaple.dhiresh.overflowmenu;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.DashboardActivity;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.ListAllApps;

import java.util.ArrayList;
import java.util.List;


public class CustomAdapterForSettings extends ArrayAdapter<String> {

    PackageManager pm;
    List<String> sl;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor preferencesEditor;
    private static final int PREFERENCE_MODE_PRIVATE = 0;
    private static final String preferenceFileName = "AppictedPreferenceFile";

    String key = "Notification";
    String ON = "On";
    String OFF = "Off";
    //Boolean status;
   // MyDBHandler dbHandler;
    //List<String> entry=new ArrayList<String>();
    //ListAllApps listAllApps=new ListAllApps();


    public CustomAdapterForSettings(Context context, List<String> sl) {
        super(context, R.layout.custom_row_settings ,sl);
        this.sl=sl;

    }

    /*public List<String> marked = null;
    public static List<String> markedhelp = null;
*/

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {

        LayoutInflater buckysInflater = LayoutInflater.from(getContext());
        View customView = buckysInflater.inflate(R.layout.custom_row_settings, parent, false);
        //CustomTextView myCustomTextView = new CustomTextView(getContext());

        String item = getItem(position);

        TextView buckysText = (TextView) customView.findViewById(R.id.buckysText);
        ImageView buckysImage = (ImageView) customView.findViewById(R.id.buckysImage);
        //ImageView markedAddict = (ImageView) customView.findViewById(R.id.addict);

        //entry = DashboardSettings.settingsMenu;


       /* if(position==2)
        {
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getContext());
            String notifications = sharedPreferences.getString(key,OFF);
            if (notifications == "On")
                buckysText.setPaintFlags(buckysText.getPaintFlags() | Paint.HINTING_OFF);
            else
                buckysText.setPaintFlags(buckysText.getPaintFlags() | Paint.HINTING_ON);
        }
*/

        buckysText.setText(item);
        //buckysImage.setImageDrawable(item);

        return customView;
    }
/*

    public static List<String> getMarked(){

        return markedhelp;
    }
*/


}

