package com.exmaple.dhiresh.overflowmenu;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.exmaple.dhiresh.models.AppsObj;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by DhirajW on 21-06-2016.
 */

public class MyDBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "Inform.db";
    public static final String TABLE_SETTINGS = "settings";
    public static final String COLUMN_PHONE = "Phone";
    public static final String COLUMN_EMAIL = "Email";

    public static final String TABLE2_SETTINGS = "appName";
    public static final String COLUMN_APPS = "apps";
    public static final String COLUMN_APPS_ACT = "activity";
    public static final String COLUMN_PM = "pm";
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_TIME = "time";

    //We need to pass database information along to superclass
    public MyDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_SETTINGS + "(" +
                COLUMN_PHONE + " LONG, " +
                COLUMN_EMAIL + " TEXT " +
                ");";
        db.execSQL(query);

        String query_app = "CREATE TABLE " + TABLE2_SETTINGS + "(" +
                COLUMN_APPS + " TEXT, " +
                COLUMN_STATUS + " INTEGER, " +
                COLUMN_APPS_ACT + " TEXT, " +
                COLUMN_TIME + " INTEGER, " +
                COLUMN_PM + " TEXT "+
                ");";
        db.execSQL(query_app);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SETTINGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE2_SETTINGS);
        onCreate(db);
    }

    //Add com.example.dhiresh.overflowmenu.a new row to the database
    public void addSettings(SettingObj settings){
        ContentValues values = new ContentValues();
        values.put(String.valueOf(COLUMN_PHONE), settings.getPhone());
        values.put(String.valueOf(COLUMN_EMAIL), settings.get_email());
        SQLiteDatabase db = getWritableDatabase();

        //  Toast.makeText(Context context, "Settings added", Toast.LENGTH_LONG);
        db.insert(TABLE_SETTINGS, null, values);
        db.close();
    }

    //Add an app to database
    public void addApps(AppsObj appsObj){

        ContentValues values = new ContentValues();
        values.put(String.valueOf(COLUMN_PM),appsObj.getApn().toString());
        values.put(String.valueOf(COLUMN_APPS), appsObj.getAppName());
        values.put(String.valueOf(COLUMN_TIME), appsObj.getTime());
        values.put(String.valueOf(COLUMN_STATUS), appsObj.getStatus());
        values.put(String.valueOf(COLUMN_APPS_ACT), appsObj.getActivityInfo().toString());
      //  Toast.makeText( context, "Context time : " + appsObj.getTime(), Toast.LENGTH_SHORT).show();
        SQLiteDatabase db = getWritableDatabase();
        db.insert(TABLE2_SETTINGS, null, values);
        db.close();
    }


    public void updateApps(AppsObj appsObj){
        ContentValues values = new ContentValues();
        values.put(String.valueOf(COLUMN_APPS), appsObj.getAppName());
        values.put(String.valueOf(COLUMN_STATUS), appsObj.getStatus());
        SQLiteDatabase db = getWritableDatabase();

        //  Toast.makeText(Context context, "Settings added", Toast.LENGTH_LONG);
        db.update(TABLE2_SETTINGS, values, appsObj.getAppName(), null);
        db.close();
    }

    //Delete com.example.dhiresh.overflowmenu.a product from the database
    public void deleteSettings(){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_SETTINGS); //+ COLUMN_EMAIL + "=\"" + productName + "\";");
    }

    //Delete all apps from database
    public void deleteApps(){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE2_SETTINGS); //+ COLUMN_EMAIL + "=\"" + productName + "\";");
    }

    //Delete an app from database
    public void deleteApp(AppsObj appsObj){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE2_SETTINGS + "  WHERE " + COLUMN_APPS + "=\"" + appsObj.getAppName() + "\";");
    }


    public String databaseToStringEmail(){
        String dbString = "";
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_SETTINGS + " LIMIT 1";

        //Cursor points to com.example.dhiresh.overflowmenu.a location in your results
        Cursor c = db.rawQuery(query, null);
        //Move to the first row in your results
        c.moveToFirst();
        //Position after the last row means the end of the results
        while (!c.isAfterLast()) {
            if (c.getString(c.getColumnIndex("Email")) != null) {
                dbString += c.getString(c.getColumnIndex("Email"));
                dbString += "\n";
            }
            c.moveToNext();
        }

        db.close();
        return dbString;
    }


    public String databaseToStringPhone(){
        String dbString = "";
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_SETTINGS + " LIMIT 1";

        //Cursor points to com.example.dhiresh.overflowmenu.a location in your results
        Cursor c = db.rawQuery(query, null);
        //Move to the first row in your results
        c.moveToFirst();

        //Position after the last row means the end of the results
        while (!c.isAfterLast()) {
            if (c.getString(c.getColumnIndex("Phone")) != null) {
                dbString += c.getString(c.getColumnIndex("Phone"));
                dbString += "\n";
            }
            c.moveToNext();
        }

        db.close();
        return dbString;
    }



    public String databaseToStringAppNames(){
        String dbString = "";
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT * FROM " + TABLE2_SETTINGS;

        //Cursor points to com.example.dhiresh.overflowmenu.a location in your results
        Cursor c = db.rawQuery(query, null);
        //Move to the first row in your results
        c.moveToFirst();

        //Position after the last row means the end of the results
        while (!c.isAfterLast()) {
            if (c.getString(c.getColumnIndex("apps")) != null) {
                dbString += c.getString(c.getColumnIndex("apps"));
                dbString += "\n";
            }
            c.moveToNext();
        }

        db.close();
        return dbString;
    }

    //Select all apps from database
    public List<String> getAllApps() {
        List<String> contactList = new ArrayList<String>();
        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE2_SETTINGS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        String dbString="";
        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                String app = new String();
                if (c.getString(c.getColumnIndex("apps")) != null) {
                     dbString = c.getString(c.getColumnIndex("apps" +
                             ""));
                }
                contactList.add(dbString);
            } while (c.moveToNext());
        }

        return contactList;
    }

    public List<AppsObj> getApps()
    {

        return null;
    }


    public List<String> getAllAppsPm() {
        List<String> contactL = new ArrayList<String>();
        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE2_SETTINGS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);
        String dbString="";
        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                String app = new String();
                if (c.getString(c.getColumnIndex("pm")) != null) {
                    dbString = c.getString(c.getColumnIndex("pm" +
                            ""));
                }
                contactL.add(dbString);
            } while (c.moveToNext());
        }

        return contactL;
    }


    public String databaseToStringAppStatus(String appName){
       String dbString = "";
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT status FROM " + TABLE2_SETTINGS + " WHERE apps= "+ appName;

        //Cursor points to com.example.dhiresh.overflowmenu.a location in your results

        Cursor c = db.rawQuery(query, null);

        //Move to the first row in your results
        c.moveToFirst();

        //Position after the last row means the end of the results
        while (!c.isAfterLast()) {
            if (c.getString(c.getColumnIndex("status")) != null) {
                dbString += c.getString(c.getColumnIndex("status"));
                dbString += "\n";
            }
            c.moveToNext();
        }

        db.close();
        return dbString;
    }

}
