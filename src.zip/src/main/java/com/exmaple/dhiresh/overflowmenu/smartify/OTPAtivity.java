package com.exmaple.dhiresh.overflowmenu.smartify;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.dialogs.OkDialog;
import com.exmaple.dhiresh.dialogs.YesNoDialog;
import com.exmaple.dhiresh.models.VerifyOTPUtil;
import com.exmaple.dhiresh.overflowmenu.BaseActivity;
import com.exmaple.dhiresh.overflowmenu.LoginActivity;
import com.exmaple.dhiresh.overflowmenu.R;
import com.exmaple.dhiresh.overflowmenu.SetPasswordActivity;
import com.exmaple.dhiresh.utils.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;



public class OTPAtivity extends BaseActivity {

    EditText etotp;
    String strotp;
    Button btnVerify;
    TextView resentotp;
    String forgotnew,strMobileNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpativity);

        etotp= (EditText) findViewById(R.id.etotp);
        btnVerify = (Button) findViewById(R.id.btnVerify);
        resentotp = (TextView) findViewById(R.id.tvResendOtp);

        forgotnew=getIntent().getStringExtra(Constants.FORGOT_NEW);
        strMobileNumber=getIntent().getStringExtra("mobileNumber");


        btnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()){
                    verifyotpApiCall();
                }
            }
        });

        resentotp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(forgotnew.equals("1")) {
                    mobilecheckApiCall();
                }else if(forgotnew.equals("0")){
                    forgotpwdMobileCheckApiCall();
                }

            }
        });
    }

    private void verifyotpApiCall() {
        showProgress("");
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key",Constants.KEY);
        paramMap.put("mobile",strMobileNumber.trim());
        paramMap.put("otp",strotp.trim());

        RetrofitTask.getInstance(OTPAtivity.this).verifyotp(paramMap, new RetrofitTask.IRetrofitTask() {

            @Override
            public void handleResponse(boolean isSuccess, String response) {
                dismissProgress();
                if(!isSuccess){
                    new OkDialog(OTPAtivity.this, response, null, null);
                    return;
                }

                Gson gson= new Gson();
                Type type = new TypeToken<VerifyOTPUtil>() {}.getType();
                VerifyOTPUtil verifyotp=null;
                verifyotp = gson.fromJson(response,type);

                if(verifyotp.getMeta_data().getCall_status().equals("1")){
                    if(verifyotp.getOtp_correct().equals("true")){
                        Intent intent = new Intent(getApplicationContext(),SetPasswordActivity.class);
                        intent.putExtra("mobileNumber",strMobileNumber);
                        intent.putExtra(Constants.FORGOT_NEW,forgotnew);
                        startActivity(intent);
                        finish();
                    }else{
                        String message=verifyotp.getMeta_data().getMsg();
                        new OkDialog(OTPAtivity.this, message, null, null);
                    }
                }else{
                    String message=verifyotp.getMeta_data().getMsg();
                    new OkDialog(OTPAtivity.this, message, null, null);
                }

            }
        });
    }

    private void mobilecheckApiCall() {
        showProgress("");
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key",Constants.KEY);
        paramMap.put("mobile",strMobileNumber.trim());

        RetrofitTask.getInstance(OTPAtivity.this).mobilecheck(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                dismissProgress();
                if(!isSuccess){
                    new OkDialog(OTPAtivity.this, getString(R.string.somethingwentwrong), null, null);
                    return;
                }

                /*Gson gson= new Gson();
                Type type = new TypeToken<MobileCheckUtil>() {}.getType();
                MobileCheckUtil mobilecheck=null;
                mobilecheck = gson.fromJson(response,type);
                if(mobilecheck.getMeta_data().getCall_status().equals("1") && mobilecheck.getLogin_data().getMobile_exists().equals("false")){
                    Intent intent = new Intent(getApplicationContext(),OTPActivity.class);
                    intent.putExtra("mobileNumber",strMobileNumber);
                    intent.putExtra(Constants.FORGOT_NEW,forgotnew);
                    startActivity(intent);
                }else{
                    String message= mobilecheck.getMeta_data().getMsg();
                    new OkDialog(SignupActivity.this, message, null, null);
                }
*/

            }
        });
    }

    private void forgotpwdMobileCheckApiCall() {
        showProgress("");
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key",Constants.KEY);
        paramMap.put("mobile",strMobileNumber.trim());

        RetrofitTask.getInstance(OTPAtivity.this).forgotpwdMobilecheck(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                dismissProgress();
                if(!isSuccess){
                    new OkDialog(OTPAtivity.this, getString(R.string.somethingwentwrong), null, null);
                    return;
                }

                /*Gson gson= new Gson();
                Type type = new TypeToken<MobileCheckUtil>() {}.getType();
                MobileCheckUtil mobilecheck=null;
                mobilecheck = gson.fromJson(response,type);

                if(mobilecheck.getMeta_data().getCall_status().equals("1") && mobilecheck.getLogin_data().getMobile_exists().equals("true")){
                    Intent intent = new Intent(getApplicationContext(),OTPActivity.class);
                    intent.putExtra("mobileNumber",strMobileNumber);
                    intent.putExtra(Constants.FORGOT_NEW,forgotnew);
                    startActivity(intent);
                }else{
                    String message= mobilecheck.getMeta_data().getMsg();
                    new OkDialog(OTPActivity.this, message, null, null);
                }
*/
            }
        });
    }

    private boolean validate() {
        strotp= etotp.getText().toString();


        String message = null;

        if(strotp==null || strotp.equals("") ){
            message= "Please Enter OTP";
        }else if(!Constants.isNetworkAvailable(OTPAtivity.this)){
            message="Check your Internet connection";
        }

        if (message != null) {
            new OkDialog(this, message, null, null);
            return false;
        }

        return true;

    }

    @Override
    public void onBackPressed() {
        String message =getString(R.string.alertstopregistration);
        new YesNoDialog(OTPAtivity.this, message,"Alert", new YesNoDialog.IYesNoDialogCallback() {
            @Override
            public void handleResponse(int responsecode) {
                if(responsecode==1){
                    Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            }
        });
    }
}
