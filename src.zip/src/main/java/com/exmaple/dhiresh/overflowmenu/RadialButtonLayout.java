package com.exmaple.dhiresh.overflowmenu;

import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.SoundEffectConstants;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.DashboardActivity;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.ListAllApps;

import java.lang.ref.WeakReference;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

/**
 *
 */


public class RadialButtonLayout extends FrameLayout {

    private final static long DURATION_SHORT = 400;
    private WeakReference<Context> weakContext;
    DashboardActivity dashboardActivity= new DashboardActivity();

    @InjectView(R.id.btn_enter)
    View btnEnter;
    @InjectView(R.id.btn_share)
    View btnShare;
    @InjectView(R.id.btn_rate)
    View btnRate;
    @InjectView(R.id.btn_addremoveapp)
    View btnAddRemoveApp;
    @InjectView(R.id.btn_settings)
    View btnSettings;
    @InjectView(R.id.btn_logout)
    View btnLogout;
    @InjectView(R.id.btn_faq)
    View btnFaq;

    private boolean isOpen = false;
    private Toast toast;
    /**
     * Default constructor
     * @param context
     */
    public RadialButtonLayout(final Context context) {
        this(context, null);
    }

    public RadialButtonLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public RadialButtonLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        weakContext = new WeakReference<Context>( context );
        LayoutInflater.from(context).inflate( R.layout.layout_radial_buttons, this);
        if (isInEditMode()) {
            //
        } else{
            ButterKnife.inject(this);
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (isInEditMode()) {
            //
        } else {

        }
    }

    private void showToast( final int resId ) {
        if ( toast != null )
            toast.cancel();
        toast = Toast.makeText( getContext(), resId, Toast.LENGTH_SHORT );
        toast.show();
    }

    @OnClick( R.id.btn_enter)
    public void onMainButtonClicked( final View btn ) {
        int resId = 0;
        if ( isOpen ) {
            // close
            hide(btnShare);
            hide(btnRate);
            hide(btnAddRemoveApp);
            hide(btnSettings);
            hide(btnLogout);
            hide(btnFaq);
            isOpen = false;
            resId = R.string.close;
        } else {
            show(btnShare, 1, 260);
            show(btnRate, 2, 270);
            show(btnAddRemoveApp, 3, 330);
            show(btnSettings, 4, 270);
            show(btnLogout, 5, 270);
            show(btnFaq, 6, 320);
            isOpen = true;
            resId = R.string.open;
        }
        showToast(resId);
        btn.playSoundEffect(SoundEffectConstants.CLICK);
    }

    @OnClick({ R.id.btn_share, R.id.btn_rate, R.id.btn_addremoveapp, R.id.btn_settings, R.id.btn_logout,R.id.btn_faq})
    public void onButtonClicked( final View btn ) {
        int resId = 0;
        switch ( btn.getId() ) {
            case R.id.btn_share:
                resId = R.string.share;
                break;
            case R.id.btn_rate:
                resId = R.string.rate;
                break;
            case R.id.btn_addremoveapp: {
                resId = R.string.addremoveapp;
                invalidate();

                for(int numberOfApps = 0; numberOfApps<100; numberOfApps++) {
                    final Intent iAppList = new Intent(getContext(), ListAllApps.class);
                    Runnable r = new Runnable() {
                        @Override
                        public void run() {
                            getContext().startActivity(iAppList);
                        }
                    };

                    Thread appListThread = new Thread(r);
                    appListThread.start();
                }

            }
                break;
            case R.id.btn_settings: {
                resId = R.string.settings;
                final Intent iAppList = new Intent(getContext(), Settings.class);
                Runnable r=new Runnable() {
                    @Override
                    public void run() {
                        getContext().startActivity(iAppList);
                    }
                };

                Thread appListThread=new Thread(r);
                appListThread.start();
            }
                break;
            case R.id.btn_logout:
                resId = R.string.logout;
               // dashboardActivity.logout();
                break;
            case R.id.btn_faq: {
                resId = R.string.faq;
                invalidate();
                final Intent iAppList = new Intent(getContext(), ListAllApps.class);
                Runnable r=new Runnable() {
                    @Override
                    public void run() {
                        getContext().startActivity(iAppList);
                    }
                };

                Thread appListThread=new Thread(r);
                appListThread.start();
            }
            break;

            default:
                resId = R.string.undefined;
        }
        showToast(resId);
        btn.playSoundEffect( SoundEffectConstants.CLICK);
    }

    private final void activityCall()
    {
        final Intent iAppList = new Intent(getContext(), ListAllApps.class);
        getContext().startActivity(iAppList);

        Runnable r=new Runnable() {
            @Override
            public void run() {
            }
        };

        Thread appListThread=new Thread(r);
        appListThread.start();
    }

    private final void hide(final View child) {
        child.animate()
                .setDuration(DURATION_SHORT)
                .translationX(0)
                .translationY(0)
                .alpha(0)
                .start();


    }

    private final void show(final View child, final int position, final int radius) {
        float angleDeg = 180.f;
        int dist = radius;
        switch (position) {
            case 1:
                angleDeg -= 30.f;
                break;
            case 2:
                angleDeg += 30.f;
                break;
            case 3:
                angleDeg += 90.f;
                break;
            case 4:
                angleDeg += 150.f;
                break;
            case 5:
                angleDeg += 210.f;
                break;
            case 6:
                angleDeg += 270.f;
                break;
            case 7:
            case 8:
            case 9:
            case 10:
                break;
        }

        final float angleRad = (float) (angleDeg * Math.PI / 180.f);

        final Float x = dist * (float) Math.cos(angleRad);
        final Float y = dist * (float) Math.sin(angleRad);
        child.animate()
                .setDuration(DURATION_SHORT)
                .translationX(x)
                .translationY(y)
                .alpha(1)
                .start();
    }
}
