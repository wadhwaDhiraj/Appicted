package com.exmaple.dhiresh.overflowmenu;

/**
 * Created by DhirajW on 21-06-2016.
 */
public class SettingObj {

    private long phone;
    private String _email;

    public SettingObj(){
    }

    public SettingObj(long phone, String email){
        this._email = email;
        this.phone = phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public void set_email(String _email) {
        this._email = _email;
    }

    public long getPhone() {
        return phone;
    }

    public String get_email() {
        return _email;
    }

}
