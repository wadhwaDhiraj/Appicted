package com.exmaple.dhiresh.overflowmenu;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.dialogs.OkDialog;
import com.exmaple.dhiresh.models.MobileCheckUtil;
import com.exmaple.dhiresh.models.UpdateMobileNumUtil;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.DashboardActivity;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.ListAllApps;
import com.exmaple.dhiresh.overflowmenu.smartify.OTPAtivity;
import com.exmaple.dhiresh.utils.AppSettings;
import com.exmaple.dhiresh.utils.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

public class Settings extends AppCompatActivity {

    MyDBHandler dbHandler;
    EditText phone;
    EditText newPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        phone = (EditText) findViewById(R.id.phone);
        newPhone = (EditText) findViewById(R.id.newPhone);
        dbHandler = new MyDBHandler(this, null, null, 1);

    }

    public void addSettings(View view){

            Map<String,String> paramMap= new HashMap<>();
            paramMap.put("key", Constants.KEY);
            paramMap.put("mentNum",phone.getText().toString());
            paramMap.put("newMentNum",newPhone.getText().toString());

            RetrofitTask.getInstance(Settings.this).updateMobile(paramMap, new RetrofitTask.IRetrofitTask() {
                @Override
                public void handleResponse(boolean isSuccess, String response) {
                    if(!isSuccess){
                        new OkDialog(Settings.this, getString(R.string.somethingwentwrong), null, null);
                        Toast.makeText(getApplicationContext(), "dismissProgress" + response, Toast.LENGTH_SHORT).show();
                        Log.e("dismissProgress : ", response);
                        return;
                    }

                    Gson gson= new Gson();
                    Type type = new TypeToken<UpdateMobileNumUtil>() {}.getType();
                    UpdateMobileNumUtil updateMobileNumUtil=null;
                    updateMobileNumUtil = gson.fromJson(response,type);
                    if(updateMobileNumUtil.getMeta_data().getCall_status().equals("1") && updateMobileNumUtil.isUpdate_status().isUpdate_status().equals("true"))
                    {
                        Toast.makeText(Settings.this, "Mentor's Number Updated Successfully", Toast.LENGTH_SHORT).show();
                        mentorUpdateMsg();
                        Intent intent = new Intent(getApplicationContext(),DashboardActivity.class);
                        startActivity(intent);
                    }else{
                        String message= updateMobileNumUtil.getMeta_data().getMsg();
                        new OkDialog(Settings.this, message, null, null);
                    }


                }
            });
        }



    void mentorUpdateMsg()
    {
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("mobile", AppSettings.getData(getApplicationContext(),AppSettings.MOBILE_NO));
        paramMap.put("mentNum",phone.getText().toString());
        paramMap.put("newMentNum",newPhone.getText().toString());

        RetrofitTask.getInstance(Settings.this).mentorUpdateMsg(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                // dismissProgress();
                if (!isSuccess) {
                    new OkDialog(Settings.this, getString(R.string.somethingwentwrong), null, null);
                    Log.e("!success mentorUpdate: ",response);
                    return;
                }

                Gson gson= new Gson();
                Type type = new TypeToken<MobileCheckUtil>() {}.getType();
                MobileCheckUtil mobilecheck = null;
                mobilecheck = gson.fromJson(response,type);
                if(mobilecheck.getMeta_data().getCall_status().equals("1")){
                    Toast.makeText(getApplicationContext(),"mentorUpdate working",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(),"Error mentorUpdate",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    public void back(View view){
        dbHandler.deleteApps();
        dbHandler.deleteSettings();
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }

    public void clearEmail(View view){
        TextView email = (TextView)findViewById(R.id.newPhone);
        email.setText("");
    }

    public void clearMobileNo(View view){
        TextView mobile = (TextView)findViewById(R.id.phone);
        mobile.setText("");
    }

}

