package com.exmaple.dhiresh.overflowmenu;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.GestureDetector.OnGestureListener;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;

import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.CheckTopActivityService;

public class MainActivity extends AppCompatActivity implements OnGestureListener{

    private GestureDetectorCompat gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
       /* Intent intent = new Intent(Settings.ACCESSIBILITY_SERVICE);
        startActivity(intent);*/
        //    Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //    setSupportActionBar(toolbar);

          super.onCreate(savedInstanceState);
          setContentView(R.layout.activity_main);

          startService(new Intent(this, CheckTopActivityService.class));

          this.gestureDetector = new GestureDetectorCompat(this,this);

         // uSM();

    }



    @Override
    public void setFinishOnTouchOutside(boolean finish) {
        super.setFinishOnTouchOutside(finish);
    }

    public void onApplist(View view)
        {
            final Intent iAppList = new Intent(this, AppList.class);
            Runnable r=new Runnable() {
                @Override
                public void run() {
                    startActivity(iAppList);
                }
            };

            Thread appListThread=new Thread(r);
            appListThread.start();

        }
        public void sendEmail(View view)
        {
            /*final Intent iSendEmail = new Intent(this,SendEmail.class);
            Runnable r=new Runnable() {
                @Override
                public void run() {
                    startActivity(iSendEmail);
                }
            };

            Thread sendEmailThread=new Thread(r);
            sendEmailThread.start();*/
        }

        public void settings(View view)
        {

            final Intent i = new Intent(this, Settings.class);
            Runnable r=new Runnable() {
                @Override
                public void run() {
                    startActivity(i);
                }
            };

            Thread settingsThread=new Thread(r);
            settingsThread.start();

        }

        public void exitApp(View view)
        {
            Runnable r=new Runnable() {
                @Override
                public void run() {
                    stopService(new Intent(getBaseContext(), MyAccessibilityService.class));
                    finish();
                }
            };

            Thread exitThread=new Thread(r);
            exitThread.start();


        }

        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu_main, menu);
            return true;
        }

    @Override
    public boolean onDown(MotionEvent e) {
        return true;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return true;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event)
    {
        this.gestureDetector.onTouchEvent(event);
        return  super.onTouchEvent(event);
    }


}
