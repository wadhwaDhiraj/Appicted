package com.exmaple.dhiresh.overflowmenu;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.exmaple.dhiresh.models.AppAddUtil;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.DashboardActivity;


import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.dialogs.OkDialog;
import com.exmaple.dhiresh.models.AppAddUtil;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.DashboardActivity;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.ListAllApps;
import com.exmaple.dhiresh.utils.AppSettings;
import com.exmaple.dhiresh.utils.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Reshma on 20-11-2016.
 */
public class LaunchAppViaDialReceiver extends BroadcastReceiver {

    DashboardSettings dashboardActivity=new DashboardSettings();
    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO Auto-generated method stub
        Log.e("Broadcast ", "Receiver");
        Bundle bundle = intent.getExtras();
        if (null == bundle) {
            Log.e("Return ", "Receiver");
            return;
        }

        String phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
        //here change the number to your desired number
        PackageManager pm = context.getPackageManager();
        ComponentName componentName = new ComponentName(context, DashboardActivity.class);
        if(pm.getComponentEnabledSetting(componentName)==2)
        checkHidePassword(phoneNumber, context);
    }

    public void checkHidePassword(String hidePwd, final Context context)
    {
        //Toast.makeText(context, "Logged in User Number : "+AppSettings.getData(context,AppSettings.MOBILE_NO), Toast.LENGTH_SHORT).show();
        final String mobile = AppSettings.getData(context,AppSettings.getData(context,AppSettings.MOBILE_NO));
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("hidePwd", hidePwd);
        paramMap.put("mobile", mobile);  // AppSettings.MOBILE_NO does not work
        RetrofitTask.getInstance(context).checkHidingPassword(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                if (!isSuccess) {
                    Log.e("getHidePwd !Success : ", response);
                    Toast.makeText(context, "!Success "+AppSettings.getData(context,AppSettings.MOBILE_NO)+" : "+response, Toast.LENGTH_SHORT).show();
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<AppAddUtil>() {}.getType();
                AppAddUtil appAddUtil;
                appAddUtil = gson.fromJson(response, type);
                Log.e("dismissProgress : ", response);
                if (appAddUtil.getMeta_data().getCall_status().equals("1") ) { // && appAddUtil.getApp_data().hidePasswordMatch()
                    //Toast.makeText(context, "API Passed", Toast.LENGTH_SHORT).show();
                    PackageManager pm = context.getPackageManager();
                    ComponentName componentName = new ComponentName(context, DashboardActivity.class);
                    pm.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
                    ComponentName componentName2 = new ComponentName(context, LoginActivity.class);
                    pm.setComponentEnabledSetting(componentName2, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
                    Intent appIntent = new Intent(context, DashboardActivity.class);
                    appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(appIntent);
                } else {
                    String message = appAddUtil.getMeta_data().getMsg();
                    Log.e("Failed get Hide Pass : " + message + " : ", response);
                    Toast.makeText(context, "API Failed : "+response, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
