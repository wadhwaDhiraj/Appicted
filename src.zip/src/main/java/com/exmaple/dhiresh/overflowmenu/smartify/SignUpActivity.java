package com.exmaple.dhiresh.overflowmenu.smartify;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.exmaple.dhiresh.overflowmenu.BaseActivity;
import com.exmaple.dhiresh.overflowmenu.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;


import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.dialogs.OkDialog;
import com.exmaple.dhiresh.models.MobileCheckUtil;
import com.exmaple.dhiresh.utils.Constants;

public class SignUpActivity extends BaseActivity {

    EditText etmobilenumber;
    String strMobileNumber;
    Button btnContinue;
    TextView existingUser,pagename;
    String forgotnew="1";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        etmobilenumber = (EditText) findViewById(R.id.etmobilenumber);
        btnContinue = (Button) findViewById(R.id.btnContinue);
        existingUser= (TextView) findViewById(R.id.tvexistinguser);
        pagename= (TextView) findViewById(R.id.pagename);

        forgotnew=getIntent().getStringExtra(Constants.FORGOT_NEW);
        if(forgotnew.equals("1")) {
            pagename.setText("Sign Up");
        }else if(forgotnew.equals("0")){
            pagename.setText("Forgot Password");
        }

        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()){
                    if(forgotnew.equals("1")) {
                        mobilecheckApiCall();
                    }else if(forgotnew.equals("0")){
                        forgotpwdMobileCheckApiCall();
                    }
                }
            }
        });
    }

    private void forgotpwdMobileCheckApiCall() {
        showProgress("");
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key",Constants.KEY);
        paramMap.put("mobile",strMobileNumber.trim());

        RetrofitTask.getInstance(SignUpActivity.this).forgotpwdMobilecheck(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                dismissProgress();
                if(!isSuccess){
                    new OkDialog(SignUpActivity.this, getString(R.string.somethingwentwrong), null, null);
                    return;
                }

                Gson gson= new Gson();
                Type type = new TypeToken<MobileCheckUtil>() {}.getType();
                MobileCheckUtil mobilecheck=null;
                mobilecheck = gson.fromJson(response,type);
                etmobilenumber.setText("");
                if(mobilecheck.getMeta_data().getCall_status().equals("1") && mobilecheck.getLogin_data().getMobile_exists().equals("true")){
                    Intent intent = new Intent(getApplicationContext(),OTPAtivity.class);
                    intent.putExtra("mobileNumber",strMobileNumber);
                    intent.putExtra(Constants.FORGOT_NEW,forgotnew);
                    startActivity(intent);
                    finish();
                }else{
                    String message= mobilecheck.getMeta_data().getMsg();
                    new OkDialog(SignUpActivity.this, message, null, null);
                }

            }
        });
    }

    private void mobilecheckApiCall() {
        showProgress("");
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key",Constants.KEY);
        paramMap.put("mobile",strMobileNumber.trim());

        RetrofitTask.getInstance(SignUpActivity.this).mobilecheck(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                dismissProgress();
                if(!isSuccess){
                    new OkDialog(SignUpActivity.this, getString(R.string.somethingwentwrong), null, null);
                    Toast.makeText(getApplicationContext(),"dismissProgress"+response,Toast.LENGTH_SHORT).show();
                    Log.e("dismissProgress : ", response);
                    return;
            }

                Gson gson= new Gson();
                Type type = new TypeToken<MobileCheckUtil>() {}.getType();
                MobileCheckUtil mobilecheck=null;
                mobilecheck = gson.fromJson(response,type);
                etmobilenumber.setText("");
                if(mobilecheck.getMeta_data().getCall_status().equals("1") && mobilecheck.getLogin_data().getMobile_exists().equals("false")){
                    Intent intent = new Intent(getApplicationContext(),OTPAtivity.class);
                    intent.putExtra("mobileNumber",strMobileNumber);
                    intent.putExtra(Constants.FORGOT_NEW,forgotnew);
                    startActivity(intent);
                }else{
                    String message= mobilecheck.getMeta_data().getMsg();
                    new OkDialog(SignUpActivity.this, message, null, null);
                }


            }
        });
    }


    private boolean validate() {
        strMobileNumber = etmobilenumber.getText().toString();

        String message = null;

        if(strMobileNumber==null || strMobileNumber.equals("") ||strMobileNumber.length()!=10  ){
            message= "Please Enter Valid Mobile Number";
        }else if(!Constants.isNetworkAvailable(SignUpActivity.this)){
            message= getString(R.string.checkInternet);
        }

        if (message != null) {
            new OkDialog(this, message, null, null);
            return false;
        }

        return true;
    }
}
