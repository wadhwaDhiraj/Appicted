
package com.exmaple.dhiresh.overflowmenu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.dialogs.OkDialog;
import com.exmaple.dhiresh.overflowmenu.BaseActivity;
import com.exmaple.dhiresh.overflowmenu.R;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.DashboardActivity;
import com.exmaple.dhiresh.overflowmenu.SplashScreen;
import com.exmaple.dhiresh.overflowmenu.smartify.SignUpActivity;
import com.exmaple.dhiresh.utils.AppSettings;
import com.exmaple.dhiresh.utils.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;



public class LoginActivity extends BaseActivity {

    EditText etusername,etpassword;
    Button btnLogin;
    TextView forgotpassword,txtSignup;
    private String strUsername, strPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        checkLogin();
        setContentView(R.layout.activity_login);

        etusername = (EditText) findViewById(R.id.edtxtUsername);
        etpassword = (EditText) findViewById(R.id.edtxtPassword);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        txtSignup= (TextView) findViewById(R.id.txtSignup);

        forgotpassword = (TextView) findViewById(R.id.tvforgotpassword);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Constants.hideKeyboard(LoginActivity.this);
                if(validate()){
                    logincheckApiCall();
                }
            }
        });

        txtSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),SignUpActivity.class);
                intent.putExtra(Constants.FORGOT_NEW,"1");
                startActivity(intent);
            }
        });

        forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),SignUpActivity.class);
                intent.putExtra(Constants.FORGOT_NEW,"0");
                startActivity(intent);
            }
        });
    }

    public void skipButton(View view)
    {
        final Intent iSkipButton = new Intent(this,DashboardActivity.class);
        Runnable r=new Runnable() {
            @Override
            public void run() {
                startActivity(iSkipButton);
            }
        };

        Thread skipButtonThread=new Thread(r);
        skipButtonThread.start();
    }

    private void logincheckApiCall() {
        showProgress("Checking..");
        final Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key",Constants.KEY);
        paramMap.put("username",strUsername.trim());
        paramMap.put("password",strPassword.trim());

        RetrofitTask.getInstance(LoginActivity.this).logincheck(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                dismissProgress();
                if(!isSuccess){
                    new OkDialog(LoginActivity.this, getString(R.string.somethingwentwrong), null, null);
                    return;
                }
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject metadat = jsonObject.getJSONObject("meta_data");
                    JSONObject login_data= jsonObject.getJSONObject("login_data");
                    String version = login_data.getString("app_verion");

                    if(login_data.getString("login_correct").equals("true")) {
                        AppSettings.putData(getApplicationContext(), AppSettings.IS_LOGIN,"true");
                        AppSettings.putData(getApplicationContext(), AppSettings.MOBILE_NO,strUsername);
                        Toast.makeText(LoginActivity.this, paramMap.get("username")+" "+paramMap.get("password"), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), DashboardActivity.class);
                        intent.putExtra("version", version);
                        startActivity(intent);
                        finish();
                    }else{
                        Toast.makeText(LoginActivity.this, "Else : "+paramMap.get("username")+" "+paramMap.get("password"), Toast.LENGTH_SHORT).show();
                        new OkDialog(LoginActivity.this,metadat.getString("msg"),null,null);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                /*Gson gson= new Gson();
                Type type = new TypeToken<LoginUtil>() {}.getType();
                LoginUtil loginDetails=null;
                loginDetails = gson.fromJson(response,type);*/

                /*if(loginDetails.getMeta_data().getCall_status().equals("1")){
                    if(loginDetails.getLogin_data().getLogin_correct().equals("true")){
                        *//*AppSettings.putData(getApplicationContext(),AppSettings.MOBILE_NO,strUsername.trim());
                        AppSettings.putData(getApplicationContext(),AppSettings.VENDOR_CODE,loginDetails.getLogin_data().getVendor_code());
                        AppSettings.putData(getApplicationContext(),AppSettings.SUBS_TYPE,loginDetails.getLogin_data().getSubscrip_type());
                        AppSettings.putData(getApplicationContext(),AppSettings.IS_LOGIN,"true");*//*
                        Intent intent = new Intent(getApplicationContext(),DashboardActivity.class);
                        startActivity(intent);
                        finish();
                    }else{
                        String message= loginDetails.getMeta_data().getMsg();
                        new OkDialog(LoginActivity.this, message, null, null);
                    }
                }*/

            }
        });

    }

    private boolean validate() {
        strUsername = etusername.getText().toString();
        strPassword = etpassword.getText().toString();

        String message = null;
        if(strUsername==null || strUsername.equals("") || strUsername.length()!=10){
            message= getString(R.string.errorvalidusername);
        }else if(strPassword.equals("") || strPassword==null){
            message= getString(R.string.errorvalidpassword);
        }else if(!Constants.isNetworkAvailable(getApplicationContext())){
            message= getString(R.string.checkInternet);
        }

        if (message != null) {
            new OkDialog(this, message, null, null);
            return false;
        }

        return true;
    }

    public void checkLogin(){
        // Check login status
        if(Boolean.parseBoolean(AppSettings.getData(getApplicationContext(),AppSettings.IS_LOGIN))){
            // user is not logged in redirect him to Login Activity
            Intent i = new Intent(getApplicationContext(), DashboardActivity.class);
            // Closing all the Activities
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            // Add new Flag to start new Activity
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // Staring Login Activity
            startActivity(i);
            finish();
        }
    }
}



