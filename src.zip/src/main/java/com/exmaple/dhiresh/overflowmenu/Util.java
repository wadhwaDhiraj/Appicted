package com.exmaple.dhiresh.overflowmenu;

/**
 * Created by Dell on 4/7/2015.
 */
public class Util {

    public  static  final String sand_box_id="APP-80W284485P519543T";
    public  static  final String paypal_liv_id="APP-0C165959RL117014F";

    public  static  final String paypal_sdk_id="AcpyN-KPDlZlAianigh1NptbXBEyi5yzJ7sgT1Lc-7HM9sc-5FlvE_3otDjo6Oo7EvLVCsKX_LAOBWvX";

}
