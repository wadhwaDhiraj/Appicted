package com.exmaple.dhiresh.overflowmenu.Shrini_Addition;

import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.dialogs.OkDialog;
import com.exmaple.dhiresh.models.AppAddUtil;
import com.exmaple.dhiresh.models.MobileCheckUtil;
import com.exmaple.dhiresh.overflowmenu.DashboardSettings;
import com.exmaple.dhiresh.overflowmenu.PayPal;
import com.exmaple.dhiresh.overflowmenu.Settings;
import com.exmaple.dhiresh.overflowmenu.SettingsActivity;
import com.exmaple.dhiresh.utils.Constants;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import com.crashlytics.android.Crashlytics;
import com.exmaple.dhiresh.dialogs.YesNoDialog;
import com.exmaple.dhiresh.overflowmenu.LoginActivity;
import com.exmaple.dhiresh.overflowmenu.R;
import com.exmaple.dhiresh.utils.AppSettings;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import io.fabric.sdk.android.Fabric;

public class DashboardActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    String pageUrl="https://play.google.com/store/apps/details?id=com.example.dhiresh.overflowmenu&hl=en";
    AdView mAdView;

    public void loadBannerAds(){

        mAdView = (AdView)findViewById(R.id.ad_view);
        AdRequest adRequest = new AdRequest.Builder()
                .setGender(AdRequest.GENDER_FEMALE)
                .build();
        mAdView.loadAd(adRequest);
        Log.e("Ad ","Added");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Fabric.with(this, new Crashlytics());
        setContentView(R.layout.activity_dashboard);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        loadBannerAds();

        startService(new Intent(this, CheckTopActivityService.class));

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        (findViewById(R.id.addApps)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Intent iAppList = new Intent(DashboardActivity.this, ListAllApps.class);
                Runnable r=new Runnable() {
                    @Override
                    public void run() {
                        startActivity(iAppList);
                        finish();
                    }
                };

                Thread appListThread=new Thread(r);
                appListThread.start();
            }
        });
        (findViewById(R.id.settings)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    final Intent iAppList = new Intent(DashboardActivity.this, DashboardSettings.class);
                    Runnable r = new Runnable() {
                        @Override
                        public void run() {
                            startActivity(iAppList);
                        }
                    };

                    Thread appListThread = new Thread(r);
                    appListThread.start();

            }
        });

        loadBannerAds();

    }

    void hideFunction()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        //input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        //builder.setView(input);

        if(Boolean.parseBoolean(AppSettings.getData(getApplicationContext(), AppSettings.IS_LOGIN))) {
            builder.setMessage("Select :");
            builder.setPositiveButton("Hide", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    hiding();
                }
            });
            builder.setNegativeButton("Update Password", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    showDialog("Test");
                    dialog.cancel();
                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();
        }
        else
            Toast.makeText(this, "Error: No internet or LogIn failure.", Toast.LENGTH_SHORT).show();
    }


    void showDialog(String str) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Hiding Code");

// Set up the input
        final EditText input = new EditText(this);
// Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setInputType(InputType.TYPE_TEXT_VARIATION_WEB_EDIT_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        builder.setView(input);

// Set up the buttons
        builder.setPositiveButton("Set", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String m_Text = input.getText().toString();
                insertHidePassword(m_Text);
                Toast.makeText(DashboardActivity.this, "Code "+m_Text, Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    void insertHidePassword(String hidePassword) {

        // showProgress("");
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("mobile", AppSettings.getData(getApplicationContext(), AppSettings.MOBILE_NO));
        paramMap.put("hidePassword", hidePassword);


        RetrofitTask.getInstance(DashboardActivity.this).insertHidePassword(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                // dismissProgress();
                if (!isSuccess) {
                    //new OkDialog(CheckTopActivityService.this, getString(R.string.somethingwentwrong), null, null);
                    Log.e("dismiss insertHidePwd: ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<MobileCheckUtil>() {
                }.getType();
                MobileCheckUtil mobilecheck = null;
                mobilecheck = gson.fromJson(response, type);
                Log.e("response instHidePwd: ", response);
                if (mobilecheck.getMeta_data().getCall_status().equals("1")) {
                    Toast.makeText(getApplicationContext(), "insertHidePassword IF", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "insertHidePassword ELSE", Toast.LENGTH_SHORT).show();
                    /*String message= mobilecheck.getMeta_data().getMsg();
                    new OkDialog(CheckTopActivityService.this, message, null, null);*/
                }

            }
        });
    }


    private void invite(){
        final Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, pageUrl);

        try {
            startActivity(Intent.createChooser(intent, "Select an action"));
        } catch (android.content.ActivityNotFoundException ex) {

        }
    }


    AlertDialog mAlertDialog;
    protected void rateUsDialog( ){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(R.layout.rate_us);
        builder.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                mAlertDialog.dismiss();
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("market://details?id=com.xymob.callnow"));
                startActivity(intent);

            }
        });

        builder.setNegativeButton("LATER", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                mAlertDialog.dismiss();

            }
        });
        if (mAlertDialog != null) {
            mAlertDialog.dismiss();
        }
        mAlertDialog = builder.create();
        mAlertDialog.setCancelable(false);
        mAlertDialog.show();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    private void logout() {

        new YesNoDialog(this, getString(R.string.alertlogout), null, new YesNoDialog.IYesNoDialogCallback() {
            @Override
            public void handleResponse(int responsecode) {
                if(responsecode == 1) {
                    AppSettings.putData(getApplicationContext(), AppSettings.IS_LOGIN, "false");
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }
            }
        });

    }

    private void donate(){
        Intent intent = new Intent(getApplicationContext(), PayPal.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }


    private void hiding() {

        ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Hiding..");
        progressDialog.show();

        PackageManager pm = getApplicationContext().getPackageManager();

        ComponentName componentName = new ComponentName(getApplicationContext(), DashboardActivity.class);
        pm.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);

        ComponentName componentName2 = new ComponentName(getApplicationContext(), LoginActivity.class);
        pm.setComponentEnabledSetting(componentName2, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);

        Toast.makeText(this, "App is hidden", Toast.LENGTH_SHORT).show();

        if(progressDialog!=null)
            progressDialog.dismiss();
        //finish();

    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            invite();
        } else if (id == R.id.nav_gallery) {
            rateUsDialog();
        }
        else if(id== R.id.nav_logout){
            logout();
        }
        else if(id == R.id.nav_hideit){
            hideFunction();
        }
        else if(id == R.id.nav_donate){
            donate();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
