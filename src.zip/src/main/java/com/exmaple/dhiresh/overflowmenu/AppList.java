package com.exmaple.dhiresh.overflowmenu;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.exmaple.dhiresh.models.AppsObj;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class AppList extends AppCompatActivity {

    MyDBHandler dbHandler;
    List<String> checkedApps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_list);

        List<ResolveInfo> apps = null;

        try {
            apps = getInstalledComponentList();
        }
        catch(PackageManager.NameNotFoundException e)
        {
            Toast.makeText(findViewById(R.id.view).getContext(), "Apps Not Found", Toast.LENGTH_LONG).show();
        }

        dbHandler = new MyDBHandler(getApplicationContext(), null, null, 1);
        final PackageManager packageManager = getPackageManager();
        final ListAdapter appsAdapter = new CustomAdapter(this, apps, packageManager, dbHandler);
        final ListView appsListView = (ListView)findViewById(R.id.AppListView);
        appsListView.setAdapter(appsAdapter);

        checkedApps = dbHandler.getAllApps();


        if(checkedApps.contains(apps))
        {
            Collections.sort(checkedApps,new Comparator<String>() {
                @Override
                public int compare(String arg1, String arg0) {
                    return arg1.compareTo(arg0);
                }
            });
          //  Toast.makeText(this,"IF IF IF",Toast.LENGTH_SHORT).show();
        }
        else {
            Collections.sort(apps, new Comparator<ResolveInfo>() {
                @Override
                public int compare(ResolveInfo arg1, ResolveInfo arg0) {
                    return (arg1.loadLabel(packageManager).toString()).compareTo(arg0.loadLabel(packageManager).toString());
                }
            });
            //Toast.makeText(this,"ELSE ELSE ELSE",Toast.LENGTH_SHORT).show();
        }


        final AppsObj appsObj = new AppsObj();

        appsListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        appsListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);

                        ResolveInfo ri = (ResolveInfo)parent.getItemAtPosition(position);
                        ActivityInfo ac = ri.activityInfo;
                        String apn = ri.activityInfo.applicationInfo.processName;
                        Log.i("APN",apn);
                        String appName = (String)ri.loadLabel(packageManager);
                       // Toast.makeText(getApplicationContext(),appName,Toast.LENGTH_SHORT).show();
                        List<String> allApps = dbHandler.getAllApps();
                        if(!allApps.contains(appName))
                        {
                          //  String pkgName=PInfo.getInstalledApps(AppList.this,false).get(position).pname;
                            appsObj.setActivityInfo(ac);
                            appsObj.setApn(apn);
                            appsObj.setAppName(appName);
                            appsObj.setStatus(1);
                            appsObj.setTime(1);
                            dbHandler.addApps(appsObj);
                        }
                        else
                        {
                            appsObj.setApn(apn);
                            appsObj.setActivityInfo(ac);
                            appsObj.setAppName(appName);
                            appsObj.setStatus(0);
                            dbHandler.deleteApp(appsObj);
                        }

                        int index = appsListView.getFirstVisiblePosition();
                        View v = appsListView.getChildAt(0);
                        int top = (v == null) ? 0 : v.getTop();
                        appsListView.setAdapter(appsAdapter);
                        appsListView.setSelectionFromTop(index, top);

                      //  Toast.makeText(getApplicationContext(), dbHandler.databaseToStringAppNames(), Toast.LENGTH_SHORT).show();

                    }
                }
        );
    }


    private List<ResolveInfo> getInstalledComponentList()
            throws PackageManager.NameNotFoundException {

        final Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> ril= getPackageManager().queryIntentActivities(mainIntent, 0);
        return ril;
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
