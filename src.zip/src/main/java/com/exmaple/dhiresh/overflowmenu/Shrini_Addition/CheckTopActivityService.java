package com.exmaple.dhiresh.overflowmenu.Shrini_Addition;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.dialogs.OkDialog;
import com.exmaple.dhiresh.models.AppAddUtil;
import com.exmaple.dhiresh.models.MobileCheckUtil;
import com.exmaple.dhiresh.overflowmenu.AndroidAppProcessLoader;
import com.exmaple.dhiresh.models.AppsObj;
import com.exmaple.dhiresh.overflowmenu.DTO.OpenedAddictedApp;
import com.exmaple.dhiresh.overflowmenu.MyDBHandler;
import com.exmaple.dhiresh.overflowmenu.R;
import com.exmaple.dhiresh.utils.AppSettings;
import com.exmaple.dhiresh.utils.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jaredrummler.android.processes.models.AndroidAppProcess;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

public class CheckTopActivityService extends Service implements AndroidAppProcessLoader.Listener {

    private static final long INTERVAL = TimeUnit.SECONDS.toMillis(5); // periodic interval to check in seconds -> 2 seconds
    private static final String TAG = CheckTopActivityService.class.getSimpleName();
    private NotificationManager mManager;
    Notification myNotication;
    private Thread t = null;
    private Context ctx = null;
    private boolean running = false;
    private Integer appTime;
    Timer timer;
    ArrayList<AndroidAppProcess> myRunningProcesses;
    static OpenedAddictedApp openedAddictedApp;
    static int no_of_rows_overlimit;
    static int no_of_rows_limitCheck;
    static Integer send_time;
    String key = "Notification";
    String ON = "On";
    String OFF = "Off";
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor preferencesEditor;
    private static final int PREFERENCE_MODE_PRIVATE = 0;
    private static final String preferenceFileName = "AppictedPreferenceFile";


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "Starting service 'CheckTopActivityService'");
        running = true;
        ctx = this;
        timer = new Timer();

        // start a thread that periodically checks if your app is in the foreground
        t = new Thread(new Runnable() {
            @Override
            public void run() {
                do {
                    executorMethod();
                    try {
                        Thread.sleep(INTERVAL);
                    } catch (InterruptedException e) {
                        Log.i(TAG, "Thread interrupted: 'CheckTopActivityService'");
                    }
                } while (running);
                stopSelf();
            }
        });

        t.start();
        return Service.START_STICKY;
    }


    @Override
    public void onComplete(List<AndroidAppProcess> processes) {
        Log.i(TAG, "Load Processes'");
        myRunningProcesses = new ArrayList<>();
        myRunningProcesses = (ArrayList) processes;
        isInBackground();
    }


    void executorMethod() {
        new AndroidAppProcessLoader(ctx, this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }

    void generateNotification(String AppName) {

        mManager = (NotificationManager) ctx.getApplicationContext().getSystemService(ctx.getApplicationContext().NOTIFICATION_SERVICE);
        Intent intent1 = new Intent(ctx.getApplicationContext(), DashboardActivity.class);
        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        PendingIntent pendingNotificationIntent = PendingIntent.getActivity(ctx.getApplicationContext(), 0, intent1, PendingIntent.FLAG_UPDATE_CURRENT);

        Log.e("Showing notification : ","Part 1");

        Notification.Builder builder = new Notification.Builder(ctx.getApplicationContext());

        builder.setContentTitle("Addiction Alert");
        builder.setStyle(new Notification.BigTextStyle().bigText(AppName + " is being used. "));
        builder.setSmallIcon(R.drawable.notify);
        builder.setContentIntent(pendingNotificationIntent);
        builder.setSound(soundUri);
        builder.setAutoCancel(true);

        myNotication = builder.build();

        Log.e("Showing notification : ","Part 2");

        Random random = new Random();
        int m = random.nextInt(9999 - 1000) + 1000;
        mManager.notify(m, myNotication);

    }


    void overlimitaddiction(String appName) {
        // showProgress("");
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("mobile", AppSettings.getData(getApplicationContext(), AppSettings.MOBILE_NO));
        paramMap.put("appName",appName);

        RetrofitTask.getInstance(CheckTopActivityService.this).overlimitaddiction(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                // dismissProgress();
                if (!isSuccess) {
                    new OkDialog(CheckTopActivityService.this, getString(R.string.somethingwentwrong), null, null);
                    Log.e("dis overlimitaddict: ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<MobileCheckUtil>() {
                }.getType();
                MobileCheckUtil mobilecheck = null;
                mobilecheck = gson.fromJson(response, type);
                Log.e("resp overlimitaddict: ", response);
                if (mobilecheck.getMeta_data().getCall_status().equals("1")) {
                   // Toast.makeText(getApplicationContext(), "overlimitaddiction IF", Toast.LENGTH_SHORT).show();
                } else {
                   // Toast.makeText(getApplicationContext(), "overlimitaddiction ELSE", Toast.LENGTH_SHORT).show();
                    /*String message= mobilecheck.getMeta_data().getMsg();
                    new OkDialog(CheckTopActivityService.this, message, null, null);*/
                }

            }
        });
    }


    void overlimitMsgCount(final String appName) {

        // showProgress("");
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("mobile", AppSettings.getData(getApplicationContext(), AppSettings.MOBILE_NO));

        RetrofitTask.getInstance(CheckTopActivityService.this).overlimitMsgCount(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                // dismissProgress();
                if (!isSuccess) {
                    //new OkDialog(CheckTopActivityService.this, getString(R.string.somethingwentwrong), null, null);
                   // Toast.makeText(getApplicationContext(), "!isSuccess overlimitMsgCount()", Toast.LENGTH_SHORT).show();
                    Log.e("dis overlimitMsgCount: ", response);
                    return;
                }
                Gson gson = new Gson();
                Type type = new TypeToken<MobileCheckUtil>() {
                }.getType();
                MobileCheckUtil mobilecheck = null;
                mobilecheck = gson.fromJson(response, type);
                Log.e("res overlimitMsgCount: ", response);
                // etmobilenumber.setText("");
                if (mobilecheck.getMeta_data().getCall_status().equals("1")) {
                    no_of_rows_overlimit = mobilecheck.getLogin_data().getNoOfRows();
                    if (no_of_rows_overlimit >= 50) {
                        limitCheck();
                    } else
                        overlimitaddiction(appName);
                    //Toast.makeText(getApplicationContext(), "overlimitMsgCount IF " + no_of_rows_overlimit, Toast.LENGTH_SHORT).show();
                } else {
                    //Toast.makeText(getApplicationContext(), "overlimitMsgCount ELSE", Toast.LENGTH_SHORT).show();
                    /*String message= mobilecheck.getMeta_data().getMsg();
                    new OkDialog(CheckTopActivityService.this, message, null, null);*/
                }

            }
        });
    }


    void limitCheck() {
        // showProgress("");
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("mobile", AppSettings.getData(getApplicationContext(), AppSettings.MOBILE_NO));

        RetrofitTask.getInstance(CheckTopActivityService.this).limitCheck(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                // dismissProgress();
                if (!isSuccess) {
                    //  new OkDialog(CheckTopActivityService.this, getString(R.string.somethingwentwrong), null, null);
                    Log.e("dismiss limitCheck: ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<MobileCheckUtil>() {
                }.getType();
                MobileCheckUtil mobilecheck = null;
                mobilecheck = gson.fromJson(response, type);
                Log.e("response limitCheck: ", response);
                // etmobilenumber.setText("");
                if (mobilecheck.getMeta_data().getCall_status().equals("1")) {
                    no_of_rows_limitCheck = mobilecheck.getLogin_data().getNoOfRows();
                    if (no_of_rows_limitCheck == 0)
                        limitOfMsgs();
                    //Toast.makeText(getApplicationContext(), "limitCheck IF" + mobilecheck.getLogin_data().getNoOfRows(), Toast.LENGTH_SHORT).show();
                } else {
                    //Toast.makeText(getApplicationContext(), "limitCheck ELSE", Toast.LENGTH_SHORT).show();
                    /*String message= mobilecheck.getMeta_data().getMsg();
                    new OkDialog(CheckTopActivityService.this, message, null, null);*/
                }

            }
        });
    }


    void limitOfMsgs() {

        // showProgress("");
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("mobile", AppSettings.getData(getApplicationContext(), AppSettings.MOBILE_NO));


        RetrofitTask.getInstance(CheckTopActivityService.this).limitOfMsgs(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                // dismissProgress();
                if (!isSuccess) {
                    //new OkDialog(CheckTopActivityService.this, getString(R.string.somethingwentwrong), null, null);
                    Log.e("dismiss limitOfMsgs: ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<MobileCheckUtil>() {
                }.getType();
                MobileCheckUtil mobilecheck = null;
                mobilecheck = gson.fromJson(response, type);
                Log.e("response limitOfMsgs: ", response);
                // etmobilenumber.setText("");
                if (mobilecheck.getMeta_data().getCall_status().equals("1")) {
                    //Toast.makeText(getApplicationContext(), "limitOfMsgs IF", Toast.LENGTH_SHORT).show();
                } else {
                    //Toast.makeText(getApplicationContext(), "limitOfMsgs ELSE", Toast.LENGTH_SHORT).show();
                    /*String message= mobilecheck.getMeta_data().getMsg();
                    new OkDialog(CheckTopActivityService.this, message, null, null);*/
                }

            }
        });
    }


    void getAddictionTime(String appName) {
        // showProgress("");
        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("mobile", AppSettings.getData(getApplicationContext(), AppSettings.MOBILE_NO));
        paramMap.put("appName", appName);

        RetrofitTask.getInstance(CheckTopActivityService.this).getAddictionTime(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                // dismissProgress();
                if (!isSuccess) {
                    //new OkDialog(CheckTopActivityService.this, getString(R.string.somethingwentwrong), null, null);
                    //Toast.makeText(CheckTopActivityService.this, "!isSuccess getAddictionTime", Toast.LENGTH_SHORT).show();
                    Log.e("dismiss getAddnTime: ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<AppAddUtil>() {
                }.getType();
                AppAddUtil appAddUtil = null;
                appAddUtil = gson.fromJson(response, type);
                Log.e("response getAddtnTime: ", response);
                // etmobilenumber.setText("");
                if (appAddUtil.getMeta_data().getCall_status().equals("1")) {
                    //Toast.makeText(getApplicationContext(), "getAddictionTime IF", Toast.LENGTH_SHORT).show();
                    Integer t = appAddUtil.getApp_data().getApp_time();
                    Log.e("Time from Server "," : "+t);
                    sendTime(t);
                } else {
                    //Toast.makeText(getApplicationContext(), "getAddictionTime ELSE", Toast.LENGTH_SHORT).show();
                    /*String message= mobilecheck.getMeta_data().getMsg();
                    new OkDialog(CheckTopActivityService.this, message, null, null);*/
                }

            }
        });
    }


    private void isInBackground() {
        List<String> checkedApps = ListAllApps.checkedAppsPm;
        OpenedAddictedApp foundOpenedApps = null;

        if (checkedApps.isEmpty())
            Log.e("checkedApps ", "is Empty");
        else
            for (String appPm : checkedApps) {
                Log.e("Pm Name ", appPm);
            }

        if (myRunningProcesses != null) {
            for (AndroidAppProcess androidAppProcess : myRunningProcesses) {
                //Log.i("Gen Noti ",androidAppProcess.getPackageName());
                if ((checkedApps.contains(androidAppProcess.getPackageName())) && androidAppProcess.foreground) {
                    Log.i("Gen Noti For ", "Checked App");
                    foundOpenedApps = new OpenedAddictedApp(androidAppProcess.name, androidAppProcess.getPackageName(), getTime());

                }
            }

            if ((openedAddictedApp != null) && (foundOpenedApps != null)) {
                if (openedAddictedApp.appName.equals(foundOpenedApps.appName)) {

                    long diff = foundOpenedApps.date - openedAddictedApp.date;
                    Log.i("Diff Time : ", diff + "");
                    getAddictionTime(openedAddictedApp.appName);
                    Integer t = get_Time();
                    Toast.makeText(CheckTopActivityService.this, "final time that will be compared " + t, Toast.LENGTH_SHORT).show();
                    if(t!=null) {
                        if (diff >= (t * 60)) { //Time in seconds which currently is a minute(60 seconds)
                            Log.e("Time : ",""+t);
                            openedAddictedApp.date = foundOpenedApps.date;

                            sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
                            String notifications = sharedPreferences.getString(key,"NULL");

                            if (notifications=="On")
                                generateNotification(openedAddictedApp.appName);

                            overlimitMsgCount(openedAddictedApp.appName);
                        }
                    }
                    else
                    { //Toast.makeText(CheckTopActivityService.this, "t is NULL "+t, Toast.LENGTH_SHORT).show();
                        Log.e("Error appTime ","Time is NULL");
                    }

                }
                else {
                    openedAddictedApp = foundOpenedApps;
                }


            } else {
                openedAddictedApp = new OpenedAddictedApp();
                openedAddictedApp = foundOpenedApps;
            }
        }
    }

    void sendTime(Integer t)
    {
        send_time=t;
    }

    Integer get_Time()
    {
        return send_time;
    }

    long getTime() {
        long time = System.currentTimeMillis() / 1000;
        return time;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        Log.i(TAG, "Stopping service 'CheckTopActivityService'");
        running = false;
        super.onDestroy();
    }
}