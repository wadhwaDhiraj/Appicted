package com.exmaple.dhiresh.overflowmenu;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.exmaple.dhiresh.models.AddAppUtil;
import com.exmaple.dhiresh.models.AppsObj;
import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.DashboardActivity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import com.exmaple.dhiresh.apicalls.RetrofitTask;
import com.exmaple.dhiresh.dialogs.OkDialog;
import com.exmaple.dhiresh.dialogs.YesNoDialog;
import com.exmaple.dhiresh.models.CreaterUserUtil;
import com.exmaple.dhiresh.models.UpdatePasswordUtil;
import com.exmaple.dhiresh.utils.AppSettings;
import com.exmaple.dhiresh.utils.Constants;

public class SetPasswordActivity extends BaseActivity {

    String forgotnew;
   // EditText etnewPassword,etrePassword,etname,etschoolname,etstandard;
    EditText etUserName, etRePassword,etMentName,etMentNum,etPassword;
    String strnewPassword, strRePassword,strMobileNumber, strName, strMentName, strMentNum;
    Button btnsubmit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_password);

        etUserName= (EditText) findViewById(R.id.etUserName);
        strMobileNumber=getIntent().getStringExtra("mobileNumber");
        etMentName= (EditText) findViewById(R.id.etMentName);
        etMentNum= (EditText) findViewById(R.id.etMentNum);
        etPassword= (EditText) findViewById(R.id.etPassword);
        etRePassword = (EditText) findViewById(R.id.etRePassword);


        btnsubmit= (Button) findViewById(R.id.btnSubmit);
        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(forgotnew.equals("1")) {
                    if(validate()) {
                        createuserApiCall();
                    }
                }else if(forgotnew.equals("0")){
                    if(validate1()) {
                        updatePasswordApiCall();
                    }
                }

            }
        });


        forgotnew=getIntent().getStringExtra(Constants.FORGOT_NEW);

        if(forgotnew.equals("1")) {
            etUserName.setVisibility(View.VISIBLE);
            etMentName.setVisibility(View.VISIBLE);
            etMentNum.setVisibility(View.VISIBLE);

        }else if(forgotnew.equals("0")){
            etUserName.setVisibility(View.GONE);
            etMentName.setVisibility(View.GONE);
            etMentNum.setVisibility(View.GONE);
        }
    }

    private void updatePasswordApiCall() {
        showProgress("");
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key",Constants.KEY);
        paramMap.put("mobile",strMobileNumber.trim());
        paramMap.put("password", strnewPassword.trim());

        RetrofitTask.getInstance(SetPasswordActivity.this).updatePassword(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                dismissProgress();
                if(!isSuccess){
                    new OkDialog(SetPasswordActivity.this, getString(R.string.somethingwentwrong), null, null);
                    return;
                }

                Gson gson= new Gson();
                Type type = new TypeToken<UpdatePasswordUtil>() {}.getType();
                UpdatePasswordUtil updatePassword=null;
                updatePassword= gson.fromJson(response,type);

                if(updatePassword.getMeta_data().getCall_status().equals("1")){
                    if (updatePassword.getPassword_updated().equals("true")){
                        String message = "Password updated successfully";
                        new OkDialog(SetPasswordActivity.this, message, "Success", new OkDialog.IOkDialogCallback() {
                            @Override
                            public void handleResponse() {
                                Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        });
                    }else{
                        String message = updatePassword.getMeta_data().getMsg();
                        new OkDialog(SetPasswordActivity.this, message, null,null);
                    }
                }

            }
        });

    }

    private void createuserApiCall() {

        showProgress("");
        Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key",Constants.KEY);
        paramMap.put("mobile",strMobileNumber.trim());
        paramMap.put("password", strnewPassword.trim());
        paramMap.put("mentName", strMentName.trim());
        paramMap.put("mentNum", strMentNum.trim());
        paramMap.put("userName", strName.trim());

        RetrofitTask.getInstance(SetPasswordActivity.this).createuser(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                dismissProgress();
                if (!isSuccess) {
                    new OkDialog(SetPasswordActivity.this, response, null, null);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<CreaterUserUtil>() {
                }.getType();
                CreaterUserUtil createuser = null;
                createuser = gson.fromJson(response, type);

                if (createuser.getMeta_data().getCall_status().equals("1")) {
                    if (createuser.getVendor_data().getVendor_created().equals("true")) {
                        AppSettings.putData(getApplicationContext(), AppSettings.MOBILE_NO, strMobileNumber.trim());
                        AppSettings.putData(getApplicationContext(), AppSettings.IS_LOGIN, "true");
                        String message = "Your Registration is Successful";
                        new OkDialog(SetPasswordActivity.this, message, "Success", new OkDialog.IOkDialogCallback() {
                            @Override
                            public void handleResponse() {
                                Intent intent = new Intent(getApplicationContext(), DashboardActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();
                            }
                        });
                    }
                }

            }
        });
    }

    //Our Addition of PHP

    public void addAppApiCall(final Context context, ActivityInfo ac,String apn, String appName, Integer status,Integer t, AppsObj appsObj) {


        final Map<String,String> paramMap= new HashMap<>();
        paramMap.put("key", Constants.KEY);
        paramMap.put("appActivityInfo", ac.toString());
        paramMap.put("appApn", apn);
        paramMap.put("appName", appName);
        paramMap.put("appStatus", String.valueOf(status));
        paramMap.put("appTime",String.valueOf(t));
        paramMap.put("mobile",AppSettings.getData(context,AppSettings.MOBILE_NO));

        RetrofitTask.getInstance(SetPasswordActivity.this).addApp(paramMap, new RetrofitTask.IRetrofitTask() {
            @Override
            public void handleResponse(boolean isSuccess, String response) {
                dismissProgress();
                if (!isSuccess) {
                    Toast.makeText(context,"in set password activity",Toast.LENGTH_SHORT).show();
                    Log.e("dismissProgress : ", response);
                    return;
                }

                Gson gson = new Gson();
                Type type = new TypeToken<AddAppUtil>() {
                }.getType();
                AddAppUtil addApp = null;
                addApp = gson.fromJson(response, type);

                if (addApp.getMeta_data().getCall_status().equals("1") && addApp.getApp_data().getApp_exists().equals("false")) {
                    String message = paramMap.get("appName") + " Added Successfully";
                    Toast.makeText(context,message,Toast.LENGTH_SHORT).show();
                } else {
                    String message = addApp.getMeta_data().getMsg();
                    Toast.makeText(context,message,Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean validate() {
        strnewPassword= etPassword.getText().toString();
        strRePassword = etRePassword.getText().toString();
        strName = etUserName.getText().toString().trim();
        strMentName = etMentName.getText().toString().trim();
        strMentNum = etMentNum.getText().toString().trim();

        String message = null;

        if(strnewPassword==null || strnewPassword.equals("") ){
            message= "Please Enter New Password";
        }else if(strRePassword ==null || strRePassword.equals("")){
            message= "Please Confirm New Password";
        }else if(!strnewPassword.equals(strRePassword)) {
            message = "Password does not match";
        } else if(strName ==null || strName.equals("")){
            message= "Please Enter Your Name";
        }else if(strMentName ==null || strMentName.equals("")){
            message= "Please Enter Your Mentor's Name";
        }else if(strMentNum ==null || strMentNum.equals("")){
            message= "Please Enter your Mentor's Mobile Number";
        }
        else if(!Constants.isNetworkAvailable(SetPasswordActivity.this)){
            message= "Check your Internet connection";
        }

        if (message != null) {
            new OkDialog(this, message, null, null);
            return false;
        }

        return true;

    }

    private boolean validate1() {
        strnewPassword= etPassword.getText().toString();
        strRePassword = etRePassword.getText().toString();


        String message = null;

        if(strnewPassword==null || strnewPassword.equals("") ){
            message= "Please Enter New Password";
        }else if(strRePassword ==null || strRePassword.equals("")){
            message= "Please Confirm New Password";
        }else if(!strnewPassword.equals(strRePassword)){
            message= "Password does not match";
        }else if(!Constants.isNetworkAvailable(SetPasswordActivity.this)){
            message= "Check your Internet connection";
        }

        if (message != null) {
            new OkDialog(this, message, null, null);
            return false;
        }

        return true;

    }

    @Override
    public void onBackPressed() {
        String message =getString(R.string.alertstopregistration);
        new YesNoDialog(SetPasswordActivity.this, message,"Alert", new YesNoDialog.IYesNoDialogCallback() {
            @Override
            public void handleResponse(int responsecode) {
                if(responsecode==1){
                    Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            }
        });
    }

}
