package com.exmaple.dhiresh.overflowmenu;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.exmaple.dhiresh.overflowmenu.Shrini_Addition.ListAllApps;

import java.util.ArrayList;
import java.util.List;


public class CustomAdapter extends ArrayAdapter<ResolveInfo> implements Filterable {

    PackageManager pm;
    List<ResolveInfo> ril;
    List<String> sl;
    Boolean status;
    MyDBHandler dbHandler;
    List<String> entry=new ArrayList<String>();
    //ListAllApps listAllApps=new ListAllApps();
    public CustomAdapter(Context context, List<ResolveInfo> ril, PackageManager pm, MyDBHandler dbHandler) {
        super(context, R.layout.custom_row ,ril);
        this.pm=pm;
        this.ril=ril;
        this.dbHandler=dbHandler;

    }

    /*public CustomAdapter(Context context, List<String> sl, MyDBHandler dbHandler, PackageManager pm) {
        super(context, R.layout.custom_row ,sl);
        this.pm=pm;
        this.sl=sl;
        this.dbHandler=dbHandler;

    }*/

    public List<String> marked = null;
    public static List<String> markedhelp = null;


    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {

        LayoutInflater buckysInflater = LayoutInflater.from(getContext());
        View customView = buckysInflater.inflate(R.layout.custom_row, parent, false);
        CustomTextView myCustomTextView = new CustomTextView(getContext());

            ResolveInfo singleApp = getItem(position);
            singleApp.specificIndex = 1;
            String appName = singleApp.loadLabel(pm).toString();
            Drawable appIcon = singleApp.loadIcon(pm);

            TextView buckysText = (TextView) customView.findViewById(R.id.buckysText);
            ImageView buckysImage = (ImageView) customView.findViewById(R.id.buckysImage);
            ImageView markedAddict = (ImageView) customView.findViewById(R.id.addict);

           entry = ListAllApps.checkedApps;


            buckysText.setText(appName);

            if (entry.contains(appName))
            {

                buckysText.setPaintFlags(buckysText.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                markedAddict.setVisibility(View.VISIBLE);

            }

        buckysImage.setImageDrawable(appIcon);

        return customView;
    }

    public static List<String> getMarked(){

        return markedhelp;
    }


}

