package com.exmaple.dhiresh.apicalls;

import android.content.Context;
import android.util.Log;

import com.exmaple.dhiresh.apicalls.IRetrofit;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import com.exmaple.dhiresh.utils.Constants;

/**
 * Created by Sagar on 30-08-2016.
 */
public class RetrofitTask {

    public IRetrofitTask callback;
    private static volatile RetrofitTask retrofitTask;
    private Context mContext;
    private IRetrofit iRetrofit;

    public static RetrofitTask getInstance(Context mContext) {
        if (retrofitTask == null) {
            retrofitTask = new RetrofitTask(mContext);
        }

        return retrofitTask;
    }

    public static void makeNull() {
        retrofitTask = null;
    }

    public RetrofitTask(Context mContext) {

        this.mContext = mContext;
        OkHttpClient.Builder builder = new OkHttpClient().newBuilder();
        builder.readTimeout(1, TimeUnit.MINUTES);
        builder.connectTimeout(1, TimeUnit.MINUTES);

        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        builder.addInterceptor(interceptor);
        OkHttpClient client = builder.build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .client(client)
                .build();

        iRetrofit = retrofit.create(IRetrofit.class);

    }

    public void questions(final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.questions();
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });


    }

    public void gcmtokenupdate(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.gcmtokenupdate(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });


    }

    public void mobilecheck(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.mobilecheck(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }

    public void checkHidingPassword(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.checkHidingPassword(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true, apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false, e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {
                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }


    public void addApp(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.addApp(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }


    public void removeApp(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.removeApp(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }


    public void updateTime(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.updateTime(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }



    public void getAllApps( final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.getAllApps();
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

                callback.handleResponse(false, t.getMessage());

            }
        });


    }



    public void updateMobile(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.updateMobile(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }

    public void overlimitMsgCount(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.overlimitMsgCount(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }


    public void limitCheck(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.limitCheck(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }


    public void overlimitaddiction(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.overlimitaddiction(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }


    public void limitOfMsgs(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.limitOfMsgs(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }


    public void getAddictionTime(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.getAddictionTime(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }



    public void insertHidePassword(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.insertHidePassword(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }


    public void removeAppMsg(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.removeAppMsg(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }



    public void mentorUpdateMsg(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.mentorUpdateMsg(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        Log.e("apiResponse : ", apiResponse);
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                        Log.e("apiResponse : ", e.getMessage());//+" "+response.body().string()
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }

    public void verifyotp(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.verifyotp(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }

    public void forgotpwdMobilecheck(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.forgotpwd_mobilecheck(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });


    }

    public void createuser(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.createuser(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });

    }

    public void logincheck(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.logincheck(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }
        });


    }

    public void updatePassword(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.update_password(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {
                callback.handleResponse(false,throwable.getMessage());
            }
        });


    }

   public void submitAnswers(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.submitAnswers(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }
        });


    }

    public void articleList( final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.articlesList();
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });


    }

    public void version( final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.version();
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });



    }

    public void winners(Map<String,String> paramMap, final IRetrofitTask callback){
        this.callback=callback;

        Call<ResponseBody> responseBodyCall= iRetrofit.winners(paramMap);
        responseBodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.code() == 200) {
                    try {
                        String apiResponse = response.body().string();
                        callback.handleResponse(true,apiResponse);
                    }catch (Exception e){
                        callback.handleResponse(false,e.getMessage());
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable throwable) {

                callback.handleResponse(false,throwable.getMessage());
            }

        });


    }

    public interface IRetrofitTask {
        void handleResponse(boolean isSuccess, String response) ;
    }
}
