package com.exmaple.dhiresh.apicalls;

import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by Sagar on 30-08-2016.
 */
public interface IRetrofit {

    @POST("questions.php")
    Call<ResponseBody> questions();

    @FormUrlEncoded
    @POST("gcmtokenupdate.php")
    Call<ResponseBody> gcmtokenupdate(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("overlimitMsgCount.php")
    Call<ResponseBody> overlimitMsgCount(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("overlimitaddiction.php")
    Call<ResponseBody> overlimitaddiction(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("checkHidingPassword.php")
    Call<ResponseBody> checkHidingPassword(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("getAddictionTime.php")
    Call<ResponseBody> getAddictionTime(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("limitOfMsgs.php")
    Call<ResponseBody> limitOfMsgs(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("insertHidePassword.php")
    Call<ResponseBody> insertHidePassword(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("limitCheck.php")
    Call<ResponseBody> limitCheck(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("removeAppMsg.php")
    Call<ResponseBody> removeAppMsg(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("mentorUpdateMsg.php")
    Call<ResponseBody> mentorUpdateMsg(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("mobilecheck.php")
    Call<ResponseBody> mobilecheck(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("updateMobile.php")
    Call<ResponseBody> updateMobile(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("addApp.php")
    Call<ResponseBody> addApp(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("removeApp.php")
    Call<ResponseBody> removeApp(@FieldMap Map<String, String> paramMap);


    @FormUrlEncoded
    @POST("updateTime.php")
    Call<ResponseBody> updateTime(@FieldMap Map<String, String> paramMap);


    @POST("getAllApps.php")
    Call<ResponseBody> getAllApps();

    @FormUrlEncoded
    @POST("verifyotp.php")
    Call<ResponseBody> verifyotp(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("createuser.php")
    Call<ResponseBody> createuser(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("logincheck.php")
    Call<ResponseBody> logincheck(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("forgotpwd_mobilecheck.php")
    Call<ResponseBody> forgotpwd_mobilecheck(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("updatepassword.php")
    Call<ResponseBody> update_password(@FieldMap Map<String, String> paramMap);

    @FormUrlEncoded
    @POST("submit.php")
    Call<ResponseBody> submitAnswers(@FieldMap Map<String, String> paramMap);

    @POST("articles.php")
    Call<ResponseBody> articlesList();

    @POST("version.php")
    Call<ResponseBody> version();

    @FormUrlEncoded
    @POST("winners.php")
    Call<ResponseBody> winners(@FieldMap Map<String, String> paramMap);




}
