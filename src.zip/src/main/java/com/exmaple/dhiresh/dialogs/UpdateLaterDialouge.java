package com.exmaple.dhiresh.dialogs;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.Window;

/**
 * Created by Sagar on 04-06-2016.
 */
public class UpdateLaterDialouge {

    private AlertDialog.Builder builder;
    AlertDialog dialog;
    int responsecode=0;


    public UpdateLaterDialouge(Context context, String message, String positivebutton, String title, final IYesNoDialogCallback callback) {

        builder = new AlertDialog.Builder(context);
        builder.setMessage(message)
                .setTitle(title);
        builder.setPositiveButton(positivebutton, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                responsecode = 1;
                dialogInterface.dismiss();
            }
        });

        builder.setNegativeButton("Later", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                dialogInterface.dismiss();
            }
        });

        dialog = builder.create();
        dialog.setCancelable(false);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {

                if (callback != null)
                    callback.handleResponse(responsecode);
            }
        });

        if(!((Activity)context).isFinishing()){
            dialog.show();
        }



    }

    public boolean isShowing()
    {
        return dialog.isShowing();
    }

    public void dismissDialog()
    {
        if(dialog!=null &&dialog.isShowing())
            dialog.dismiss();
    }
    public interface IYesNoDialogCallback
    {
         void handleResponse(int responsecode);
    }
}
