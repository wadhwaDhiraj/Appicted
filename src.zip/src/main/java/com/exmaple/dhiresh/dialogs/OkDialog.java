package com.exmaple.dhiresh.dialogs;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;
import android.view.Window;


/**
 * Created by kunalk on 10/26/2015.
 */
public class OkDialog {

    private AlertDialog.Builder builder;
    AlertDialog dialog;

    public OkDialog(Context context, String message, String title, final IOkDialogCallback callback) {

        builder = new AlertDialog.Builder(context);
        if(title==null || TextUtils.isEmpty(title))
            title="Error";
        builder.setMessage(message)
                .setTitle(title);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
        dialog.invalidateOptionsMenu();
                dialogInterface.dismiss();
            }
        });

        dialog = builder.create();
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {

                if (callback != null)
                    callback.handleResponse();
            }
        });

      if(!((Activity)context).isFinishing())
           dialog.show();



    }

  public boolean isShowing()
  {
      return dialog.isShowing();
  }

  public void dismissDialog()
  {
     if(dialog!=null &&dialog.isShowing())
          dialog.dismiss();
  }

    public interface IOkDialogCallback
    {
     public void handleResponse();
    }
}
